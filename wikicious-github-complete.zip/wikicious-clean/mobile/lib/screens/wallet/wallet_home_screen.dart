import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../../theme.dart';
import '../../providers/providers.dart';
import '../../providers/social_providers.dart';
import '../../services/wallet_service.dart';

class WalletHomeScreen extends ConsumerWidget {
  const WalletHomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth    = ref.watch(authProvider);
    final balance = ref.watch(balanceProvider);
    final address = auth.address ?? '';

    return Scaffold(
      backgroundColor: WikColor.bg0,
      appBar: AppBar(
        backgroundColor: WikColor.bg0,
        title: const Text('Wallet'),
        actions: [
          IconButton(
            icon: const Icon(Icons.qr_code_outlined),
            onPressed: () => _showQR(context, address),
          ),
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [

        // Address card
        _AddressCard(address: address),
        const SizedBox(height: 16),

        // Balance card
        balance.when(
          loading: () => const _BalanceSkeleton(),
          error:   (_, __) => const _BalanceSkeleton(),
          data: (b) => _BalanceCard(balance: b),
        ),
        const SizedBox(height: 16),

        // Action buttons
        Row(children: [
          Expanded(child: _ActionBtn(icon: Icons.add, label: 'Deposit',  color: WikColor.green,  onTap: () => _showDeposit(context, address))),
          const SizedBox(width: 10),
          Expanded(child: _ActionBtn(icon: Icons.arrow_upward, label: 'Withdraw', color: WikColor.accent, onTap: () => _showWithdraw(context))),
          const SizedBox(width: 10),
          Expanded(child: _ActionBtn(icon: Icons.send_outlined, label: 'Send',    color: WikColor.text2,  onTap: () {})),
        ]),
        const SizedBox(height: 20),

        // WIK rewards card
        if (address.isNotEmpty) _WIKRewardsCard(address: address, ref: ref),
        const SizedBox(height: 20),

        // Network info
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: WikColor.bg1,
            borderRadius: BorderRadius.circular(12),
            border: const Border.fromBorderSide(BorderSide(color: WikColor.border)),
          ),
          child: Column(children: [
            _InfoRow('Network',    'Arbitrum One'),
            const SizedBox(height: 8),
            _InfoRow('Chain ID',   '42161'),
            const SizedBox(height: 8),
            _InfoRow('Currency',   'ETH + USDC'),
            const SizedBox(height: 8),
            _InfoRow('Social',     'WikiSocial (on-chain)'),
          ]),
        ),
        const SizedBox(height: 20),

        // Security section
        const _SecuritySection(),
      ]),
    );
  }

  void _showQR(BuildContext ctx, String address) {
    showModalBottomSheet(
      context: ctx,
      backgroundColor: WikColor.bg1,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Receive', style: TextStyle(color: WikColor.text1, fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 20),
          QrImageView(data: address, size: 200, backgroundColor: Colors.white),
          const SizedBox(height: 16),
          Text(WalletService.shortAddress(address), style: const TextStyle(color: WikColor.text2, fontSize: 14)),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: () { Clipboard.setData(ClipboardData(text: address)); Navigator.pop(ctx); },
            icon: const Icon(Icons.copy, size: 16),
            label: const Text('Copy address'),
          ),
        ]),
      ),
    );
  }

  void _showDeposit(BuildContext ctx, String address) {
    showModalBottomSheet(
      context: ctx,
      backgroundColor: WikColor.bg1,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => const _DepositSheet(),
    );
  }

  void _showWithdraw(BuildContext ctx) {
    showModalBottomSheet(
      context: ctx,
      backgroundColor: WikColor.bg1,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => const _WithdrawSheet(),
    );
  }
}

// ── Sub-widgets ───────────────────────────────────────────────
class _AddressCard extends StatelessWidget {
  final String address;
  const _AddressCard({required this.address});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: WikColor.bg1,
      borderRadius: BorderRadius.circular(12),
      border: const Border.fromBorderSide(BorderSide(color: WikColor.border)),
    ),
    child: Row(children: [
      Container(
        width: 36, height: 36,
        decoration: BoxDecoration(color: WikColor.accentBg, borderRadius: BorderRadius.circular(10)),
        child: const Icon(Icons.account_balance_wallet, color: WikColor.accent, size: 18),
      ),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Your wallet', style: TextStyle(color: WikColor.text3, fontSize: 11)),
        Text(address.isNotEmpty ? WalletService.shortAddress(address) : '—',
            style: const TextStyle(color: WikColor.text1, fontSize: 14, fontWeight: FontWeight.w600,
                fontFamily: 'SpaceMono')),
      ])),
      IconButton(
        icon: const Icon(Icons.copy, size: 16, color: WikColor.text3),
        onPressed: () => Clipboard.setData(ClipboardData(text: address)),
      ),
    ]),
  );
}

class _BalanceCard extends StatelessWidget {
  final AccountBalance balance;
  const _BalanceCard({required this.balance});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      gradient: const LinearGradient(
        colors: [Color(0xFF1A2040), Color(0xFF0D1525)],
        begin: Alignment.topLeft, end: Alignment.bottomRight,
      ),
      borderRadius: BorderRadius.circular(16),
      border: const Border.fromBorderSide(BorderSide(color: WikColor.border)),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Total Balance', style: TextStyle(color: WikColor.text3, fontSize: 12)),
      const SizedBox(height: 6),
      Text(
        '\$${NumberFormat('#,##0.00').format(balance.totalMargin / 1e6)}',
        style: const TextStyle(color: WikColor.text1, fontSize: 28, fontWeight: FontWeight.w800, fontFamily: 'SpaceMono'),
      ),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(child: _BalanceStat(label: 'Available', value: balance.freeMargin / 1e6, color: WikColor.green)),
        Expanded(child: _BalanceStat(label: 'In Positions', value: balance.lockedMargin / 1e6, color: WikColor.gold)),
      ]),
    ]),
  );
}

class _BalanceStat extends StatelessWidget {
  final String label;
  final double value;
  final Color  color;
  const _BalanceStat({required this.label, required this.value, required this.color});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: WikText.label(size: 11)),
    const SizedBox(height: 2),
    Text('\$${NumberFormat('#,##0.00').format(value)}',
        style: TextStyle(color: color, fontSize: 15, fontWeight: FontWeight.w700, fontFamily: 'SpaceMono')),
  ]);
}

class _BalanceSkeleton extends StatelessWidget {
  const _BalanceSkeleton();
  @override
  Widget build(BuildContext context) => Container(
    height: 120,
    decoration: BoxDecoration(color: WikColor.bg1, borderRadius: BorderRadius.circular(16)),
  );
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color  color;
  final VoidCallback onTap;
  const _ActionBtn({required this.icon, required this.label, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
      ]),
    ),
  );
}

class _WIKRewardsCard extends StatelessWidget {
  final String address;
  final WidgetRef ref;
  const _WIKRewardsCard({required this.address, required this.ref});

  @override
  Widget build(BuildContext context) {
    final rewards = ref.watch(rewardsProvider(address));
    return rewards.when(
      loading: () => const SizedBox.shrink(),
      error:   (_, __) => const SizedBox.shrink(),
      data: (r) {
        final claimable = double.tryParse(r['claimable'] ?? '0') ?? 0;
        final earned    = double.tryParse(r['totalEarned'] ?? '0') ?? 0;
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: WikColor.bg1,
            borderRadius: BorderRadius.circular(12),
            border: const Border.fromBorderSide(BorderSide(color: WikColor.border)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.token, color: WikColor.gold, size: 18),
              const SizedBox(width: 8),
              const Text('WIK Rewards', style: TextStyle(color: WikColor.text1, fontWeight: FontWeight.w700, fontSize: 14)),
            ]),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: _BalanceStat(label: 'Total Earned', value: earned,    color: WikColor.gold)),
              Expanded(child: _BalanceStat(label: 'Claimable',    value: claimable, color: WikColor.green)),
            ]),
            if (claimable > 0.01) ...[
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () { /* claim WIK */ },
                  icon: const Icon(Icons.download, size: 16),
                  label: Text('Claim ${claimable.toStringAsFixed(2)} WIK'),
                  style: ElevatedButton.styleFrom(backgroundColor: WikColor.gold, foregroundColor: Colors.black),
                ),
              ),
            ],
            const SizedBox(height: 10),
            const Text('Earn WIK by posting, liking, and trading on Wikicious',
                style: TextStyle(color: WikColor.text3, fontSize: 11)),
          ]),
        );
      },
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label, value;
  const _InfoRow(this.label, this.value);
  @override
  Widget build(BuildContext context) => Row(children: [
    Text(label, style: WikText.label(size: 12)),
    const Spacer(),
    Text(value, style: const TextStyle(color: WikColor.text1, fontSize: 13, fontWeight: FontWeight.w600)),
  ]);
}

class _SecuritySection extends ConsumerWidget {
  const _SecuritySection();
  @override
  Widget build(BuildContext context, WidgetRef ref) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: WikColor.bg1,
      borderRadius: BorderRadius.circular(12),
      border: const Border.fromBorderSide(BorderSide(color: WikColor.border)),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Security', style: TextStyle(color: WikColor.text1, fontWeight: FontWeight.w700, fontSize: 14)),
      const SizedBox(height: 12),
      _SecurityRow(
        icon: Icons.fingerprint, label: 'Biometric lock', color: WikColor.green,
        onTap: () {},
      ),
      const Divider(color: WikColor.border, height: 16),
      _SecurityRow(
        icon: Icons.vpn_key_outlined, label: 'Backup seed phrase', color: WikColor.gold,
        onTap: () {},
      ),
    ]),
  );
}

class _SecurityRow extends StatelessWidget {
  final IconData icon;
  final String   label;
  final Color    color;
  final VoidCallback onTap;
  const _SecurityRow({required this.icon, required this.label, required this.color, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Row(children: [
      Icon(icon, color: color, size: 18),
      const SizedBox(width: 10),
      Text(label, style: const TextStyle(color: WikColor.text1, fontSize: 13)),
      const Spacer(),
      const Icon(Icons.chevron_right, color: WikColor.text3, size: 18),
    ]),
  );
}

class _DepositSheet extends StatelessWidget {
  const _DepositSheet();
  @override
  Widget build(BuildContext context) => Padding(
    padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 20),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Text('Deposit USDC', style: TextStyle(color: WikColor.text1, fontSize: 18, fontWeight: FontWeight.w700)),
      const SizedBox(height: 16),
      const Text('Send USDC to your wallet address on Arbitrum One network.',
          style: TextStyle(color: WikColor.text2, fontSize: 14), textAlign: TextAlign.center),
      const SizedBox(height: 20),
      ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text('Got it')),
    ]),
  );
}

class _WithdrawSheet extends StatefulWidget {
  const _WithdrawSheet();
  @override
  State<_WithdrawSheet> createState() => _WithdrawSheetState();
}

class _WithdrawSheetState extends State<_WithdrawSheet> {
  final _amtCtrl = TextEditingController();
  final _addrCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) => Padding(
    padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 20),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Text('Withdraw USDC', style: TextStyle(color: WikColor.text1, fontSize: 18, fontWeight: FontWeight.w700)),
      const SizedBox(height: 16),
      TextField(controller: _addrCtrl,
        decoration: const InputDecoration(labelText: 'Recipient address', hintText: '0x...')),
      const SizedBox(height: 12),
      TextField(controller: _amtCtrl, keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'Amount (USDC)', hintText: '100')),
      const SizedBox(height: 20),
      SizedBox(width: double.infinity,
        child: ElevatedButton(
          onPressed: () { /* sign + send tx */ },
          child: const Text('Withdraw'),
        ),
      ),
    ]),
  );
}
