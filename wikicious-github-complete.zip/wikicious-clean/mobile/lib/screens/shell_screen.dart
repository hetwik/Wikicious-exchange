import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../theme.dart';
import '../providers/providers.dart';

class ShellScreen extends ConsumerWidget {
  final Widget child;
  const ShellScreen({super.key, required this.child});

  static const _tabs = [
    (icon: Icons.home_outlined,       active: Icons.home,             label: 'Feed',    path: '/feed'),
    (icon: Icons.explore_outlined,    active: Icons.explore,          label: 'Explore', path: '/explore'),
    (icon: Icons.candlestick_chart_outlined, active: Icons.candlestick_chart, label: 'Trade', path: '/trade'),
    (icon: Icons.account_balance_wallet_outlined, active: Icons.account_balance_wallet, label: 'Wallet', path: '/wallet'),
    (icon: Icons.leaderboard_outlined, active: Icons.leaderboard,     label: 'Ranks',   path: '/leaderboard'),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final location  = GoRouterState.of(context).uri.path;
    final unread    = ref.watch(unreadNotificationsProvider);
    final currentIdx = _tabs.indexWhere((t) => location.startsWith(t.path));

    return Scaffold(
      backgroundColor: WikColor.bg0,
      body: Stack(children: [
        child,
        // Compose FAB — visible on feed/explore
        if (location == '/feed' || location == '/explore')
          Positioned(
            bottom: 80, right: 16,
            child: _ComposeFab(),
          ),
      ]),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: WikColor.border)),
        ),
        child: BottomNavigationBar(
          currentIndex: currentIdx < 0 ? 0 : currentIdx,
          onTap: (i) => context.go(_tabs[i].path),
          items: _tabs.map((t) => BottomNavigationBarItem(
            icon: Stack(children: [
              Icon(t.icon),
              if (t.path == '/feed' && unread > 0)
                Positioned(
                  right: 0, top: 0,
                  child: Container(
                    width: 8, height: 8,
                    decoration: const BoxDecoration(
                      color: WikColor.red, shape: BoxShape.circle,
                    ),
                  ),
                ),
            ]),
            activeIcon: Icon(t.active),
            label: t.label,
          )).toList(),
        ),
      ),
    );
  }
}

class _ComposeFab extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FloatingActionButton(
      backgroundColor: WikColor.accent,
      foregroundColor: Colors.white,
      elevation: 4,
      onPressed: () => context.push('/compose'),
      child: const Icon(Icons.edit_outlined, size: 22),
    );
  }
}
