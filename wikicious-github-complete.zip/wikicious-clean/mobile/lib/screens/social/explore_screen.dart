import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../theme.dart';
import '../../providers/social_providers.dart';
import '../../providers/providers.dart';
import '../../widgets/social/post_card.dart';

// ── Explore Screen ─────────────────────────────────────────────────────────
class ExploreScreen extends ConsumerStatefulWidget {
  const ExploreScreen({super.key});
  @override
  ConsumerState<ExploreScreen> createState() => _ExploreState();
}

class _ExploreState extends ConsumerState<ExploreScreen> {
  final _search  = TextEditingController();
  bool  _searching = false;
  Map<String, dynamic>? _results;

  @override
  Widget build(BuildContext context) {
    final trending = ref.watch(trendingProvider);

    return Scaffold(
      backgroundColor: WikColor.bg0,
      appBar: AppBar(
        backgroundColor: WikColor.bg0,
        title: TextField(
          controller: _search,
          style: const TextStyle(color: WikColor.text1),
          onChanged: _onSearch,
          onSubmitted: _onSearch,
          decoration: InputDecoration(
            hintText: 'Search traders, posts, #tags...',
            hintStyle: const TextStyle(color: WikColor.text3, fontSize: 14),
            prefixIcon: const Icon(Icons.search, color: WikColor.text3, size: 20),
            suffixIcon: _search.text.isNotEmpty
                ? IconButton(
                    icon: const Icon(Icons.close, color: WikColor.text3, size: 18),
                    onPressed: () { _search.clear(); setState(() => _results = null); },
                  )
                : null,
            filled: true,
            fillColor: WikColor.bg2,
            contentPadding: const EdgeInsets.symmetric(vertical: 8),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
          ),
        ),
      ),
      body: _results != null ? _SearchResults(results: _results!) : _ExploreDefault(trending: trending),
    );
  }

  Future<void> _onSearch(String q) async {
    if (q.length < 2) { setState(() => _results = null); return; }
    try {
      final r = await SocialApi.search(q);
      if (mounted) setState(() => _results = r);
    } catch (_) {}
  }
}

class _ExploreDefault extends ConsumerWidget {
  final AsyncValue<List<Map<String, dynamic>>> trending;
  const _ExploreDefault({required this.trending});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final explore = ref.watch(exploreProvider);

    return RefreshIndicator(
      color: WikColor.accent,
      backgroundColor: WikColor.bg1,
      onRefresh: () => ref.read(exploreProvider.notifier).refresh(),
      child: ListView(children: [
        // Trending hashtags
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Text('Trending', style: TextStyle(color: WikColor.text1, fontSize: 16, fontWeight: FontWeight.w700)),
        ),
        trending.when(
          loading: () => const SizedBox(height: 80, child: Center(child: CircularProgressIndicator(strokeWidth: 2, color: WikColor.accent))),
          error:   (_, __) => const SizedBox.shrink(),
          data: (tags) => SizedBox(
            height: 44,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemCount: tags.length,
              itemBuilder: (_, i) => _TagChip(tag: tags[i]['tag'] as String, count: tags[i]['post_count'] as int),
            ),
          ),
        ),

        const Padding(
          padding: EdgeInsets.fromLTRB(16, 20, 16, 8),
          child: Text('Top Posts', style: TextStyle(color: WikColor.text1, fontSize: 16, fontWeight: FontWeight.w700)),
        ),

        // Top posts
        explore.when(
          loading: () => const Center(child: CircularProgressIndicator(color: WikColor.accent)),
          error:   (e, _) => Center(child: Text('$e', style: const TextStyle(color: WikColor.red))),
          data: (posts) => Column(
            children: posts.map((p) => PostCard(post: p)).toList(),
          ),
        ),
      ]),
    );
  }
}

class _SearchResults extends StatelessWidget {
  final Map<String, dynamic> results;
  const _SearchResults({required this.results});

  @override
  Widget build(BuildContext context) {
    final profiles = results['profiles'] as List? ?? [];
    final posts    = results['posts']    as List? ?? [];
    final tags     = results['tags']     as List? ?? [];

    return ListView(children: [
      if (profiles.isNotEmpty) ...[
        const _SectionHeader('People'),
        ...profiles.map((p) => _ProfileRow(profile: SocialProfile.fromJson(p))),
      ],
      if (tags.isNotEmpty) ...[
        const _SectionHeader('Hashtags'),
        ...tags.map((t) => ListTile(
          leading: const Icon(Icons.tag, color: WikColor.accent),
          title: Text('#${t['tag']}', style: const TextStyle(color: WikColor.text1)),
          trailing: Text('${t['count']} posts', style: WikText.label()),
          onTap: () => context.push('/hashtag/${t['tag']}'),
        )),
      ],
      if (posts.isNotEmpty) ...[
        const _SectionHeader('Posts'),
        ...posts.map((p) => PostCard(post: SocialPost.fromJson(p))),
      ],
      if (profiles.isEmpty && posts.isEmpty && tags.isEmpty)
        const Center(
          child: Padding(
            padding: EdgeInsets.all(40),
            child: Text('No results found', style: TextStyle(color: WikColor.text3)),
          ),
        ),
    ]);
  }
}

class _TagChip extends StatelessWidget {
  final String tag;
  final int    count;
  const _TagChip({required this.tag, required this.count});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: () => context.push('/hashtag/$tag'),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: WikColor.accentBg,
        borderRadius: BorderRadius.circular(20),
        border: const Border.fromBorderSide(BorderSide(color: WikColor.accent, width: 0.5)),
      ),
      child: Text('#$tag  $count', style: const TextStyle(color: WikColor.accent, fontSize: 13, fontWeight: FontWeight.w600)),
    ),
  );
}

class _ProfileRow extends StatelessWidget {
  final SocialProfile profile;
  const _ProfileRow({required this.profile});
  @override
  Widget build(BuildContext context) => ListTile(
    leading: CircleAvatar(
      backgroundColor: WikColor.bg3,
      backgroundImage: profile.avatarUrl.isNotEmpty ? CachedNetworkImageProvider(profile.avatarUrl) : null,
      child: profile.avatarUrl.isEmpty ? const Icon(Icons.person, color: WikColor.text3) : null,
    ),
    title: Row(children: [
      Text(profile.displayName.isNotEmpty ? profile.displayName : '@${profile.handle}',
          style: const TextStyle(color: WikColor.text1, fontWeight: FontWeight.w700)),
      if (profile.verified) ...[const SizedBox(width: 4), const Icon(Icons.verified, size: 14, color: WikColor.accent)],
      if (profile.traderVerified) ...[const SizedBox(width: 4), const Icon(Icons.candlestick_chart, size: 12, color: WikColor.gold)],
    ]),
    subtitle: Text('@${profile.handle}  ·  ${profile.followerCount} followers',
        style: WikText.label(size: 12)),
    onTap: () => context.push('/profile/${profile.address}'),
  );
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
    child: Text(title, style: const TextStyle(color: WikColor.text1, fontWeight: FontWeight.w700, fontSize: 14)),
  );
}

// ── Notifications Screen ───────────────────────────────────────────────────
class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final address = ref.watch(authProvider).address ?? '';
    final data    = ref.watch(notificationsProvider(address));

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (address.isNotEmpty) SocialApi.markRead(address);
      ref.read(unreadNotificationsProvider.notifier).state = 0;
    });

    return Scaffold(
      backgroundColor: WikColor.bg0,
      appBar: AppBar(
        backgroundColor: WikColor.bg0,
        title: const Text('Notifications'),
      ),
      body: data.when(
        loading: () => const Center(child: CircularProgressIndicator(color: WikColor.accent)),
        error:   (e, _) => Center(child: Text('$e')),
        data: (d) {
          final notifs = (d['notifications'] as List?) ?? [];
          if (notifs.isEmpty) return const Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.notifications_none, size: 64, color: WikColor.text3),
              SizedBox(height: 12),
              Text('No notifications yet', style: TextStyle(color: WikColor.text3, fontSize: 16)),
            ]),
          );
          return ListView.builder(
            itemCount: notifs.length,
            itemBuilder: (_, i) => _NotifTile(notif: SocialNotification.fromJson(notifs[i])),
          );
        },
      ),
    );
  }
}

class _NotifTile extends StatelessWidget {
  final SocialNotification notif;
  const _NotifTile({required this.notif});

  IconData get _icon => switch (notif.type) {
    'like'    => Icons.favorite,
    'comment' => Icons.chat_bubble,
    'repost'  => Icons.repeat,
    'follow'  => Icons.person_add,
    _         => Icons.notifications,
  };

  Color get _color => switch (notif.type) {
    'like'    => WikColor.red,
    'comment' => WikColor.accent,
    'repost'  => WikColor.green,
    'follow'  => WikColor.gold,
    _         => WikColor.text3,
  };

  String get _text => switch (notif.type) {
    'like'    => 'liked your post',
    'comment' => 'commented on your post',
    'repost'  => 'reposted your post',
    'follow'  => 'followed you',
    _         => 'interacted with you',
  };

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: notif.postId > 0 ? () => context.push('/post/${notif.postId}') : null,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: notif.read ? Colors.transparent : WikColor.accentBg,
        border: const Border(bottom: BorderSide(color: WikColor.border)),
      ),
      child: Row(children: [
        Stack(children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: WikColor.bg3,
            backgroundImage: notif.actorAvatar.isNotEmpty
                ? CachedNetworkImageProvider(notif.actorAvatar) : null,
            child: notif.actorAvatar.isEmpty ? const Icon(Icons.person, color: WikColor.text3) : null,
          ),
          Positioned(
            bottom: 0, right: 0,
            child: Container(
              width: 18, height: 18,
              decoration: BoxDecoration(color: _color, shape: BoxShape.circle),
              child: Icon(_icon, size: 10, color: Colors.white),
            ),
          ),
        ]),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          RichText(text: TextSpan(children: [
            TextSpan(text: '@${notif.actorHandle} ', style: const TextStyle(color: WikColor.text1, fontWeight: FontWeight.w700, fontSize: 14)),
            TextSpan(text: _text, style: const TextStyle(color: WikColor.text2, fontSize: 14)),
          ])),
          const SizedBox(height: 2),
          Text(
            timeago.format(DateTime.fromMillisecondsSinceEpoch(notif.ts * 1000)),
            style: WikText.label(size: 11),
          ),
        ])),
      ]),
    ),
  );
}

// ── Hashtag Screen ─────────────────────────────────────────────────────────
class HashtagScreen extends ConsumerWidget {
  final String tag;
  const HashtagScreen({super.key, required this.tag});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: WikColor.bg0,
      appBar: AppBar(
        backgroundColor: WikColor.bg0,
        title: Text('#$tag'),
      ),
      body: FutureBuilder<List<SocialPost>>(
        future: SocialApi.getHashtagPosts(tag),
        builder: (ctx, snap) {
          if (snap.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator(color: WikColor.accent));
          if (snap.hasError)
            return Center(child: Text('${snap.error}', style: const TextStyle(color: WikColor.red)));
          final posts = snap.data ?? [];
          if (posts.isEmpty) return Center(
            child: Text('No posts for #$tag yet', style: const TextStyle(color: WikColor.text3)),
          );
          return ListView.builder(
            itemCount: posts.length,
            itemBuilder: (_, i) => PostCard(post: posts[i]),
          );
        },
      ),
    );
  }
}

// ── Post Detail Screen ─────────────────────────────────────────────────────
class PostDetailScreen extends ConsumerWidget {
  final int postId;
  const PostDetailScreen({super.key, required this.postId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: WikColor.bg0,
      appBar: AppBar(backgroundColor: WikColor.bg0, title: const Text('Post')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: SocialApi.getPost(postId),
        builder: (ctx, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: WikColor.accent));
          final post     = SocialPost.fromJson(snap.data!['post']);
          final comments = (snap.data!['comments'] as List? ?? []).map((j) => SocialPost.fromJson(j)).toList();
          final content  = snap.data!['content'];
          final textPost = content is Map ? content['text'] as String? : null;
          final withText = SocialPost.fromJson({...snap.data!['post'], 'text': textPost});

          return ListView(children: [
            PostCard(post: withText, showThread: true),
            // Reply box
            Container(
              margin: const EdgeInsets.all(12),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: WikColor.bg2,
                borderRadius: BorderRadius.circular(10),
                border: const Border.fromBorderSide(BorderSide(color: WikColor.border)),
              ),
              child: GestureDetector(
                onTap: () => context.push('/compose?replyTo=$postId'),
                child: const Row(children: [
                  Icon(Icons.chat_bubble_outline, size: 16, color: WikColor.text3),
                  SizedBox(width: 8),
                  Text('Reply to this post...', style: TextStyle(color: WikColor.text3, fontSize: 14)),
                ]),
              ),
            ),
            if (comments.isNotEmpty)
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 4, 16, 0),
                child: Text('Replies', style: TextStyle(color: WikColor.text2, fontWeight: FontWeight.w600, fontSize: 13)),
              ),
            ...comments.map((c) => PostCard(post: c)),
          ]);
        },
      ),
    );
  }
}
