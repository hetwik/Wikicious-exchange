import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import '../../theme.dart';
import '../../providers/providers.dart';
import '../../providers/social_providers.dart';
import '../../services/api_service.dart';

class ComposeScreen extends ConsumerStatefulWidget {
  final int? replyToId;
  const ComposeScreen({super.key, this.replyToId});
  @override
  ConsumerState<ComposeScreen> createState() => _ComposeState();
}

class _ComposeState extends ConsumerState<ComposeScreen> {
  final _ctrl   = TextEditingController();
  final _focus  = FocusNode();
  bool  _posting  = false;
  bool  _uploading = false;
  String? _mediaUrl;
  String? _mediaHash;
  int     _mediaType = 0; // 0=none 1=image 2=video
  List<String> _tags = [];
  SocialPost?  _replyTo;

  int get _charCount => _ctrl.text.length;
  bool get _canPost  => _charCount > 0 && _charCount <= 10000 && !_posting;

  @override
  void initState() {
    super.initState();
    _focus.requestFocus();
    if (widget.replyToId != null) _loadReplyTo();
  }

  Future<void> _loadReplyTo() async {
    try {
      final data = await SocialApi.getPost(widget.replyToId!);
      if (mounted) setState(() => _replyTo = SocialPost.fromJson(data['post']));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final auth    = ref.watch(authProvider);
    final address = auth.address ?? '';

    return Scaffold(
      backgroundColor: WikColor.bg0,
      appBar: AppBar(
        backgroundColor: WikColor.bg0,
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => context.pop(),
        ),
        title: Text(widget.replyToId != null ? 'Reply' : 'New Post'),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: _PostButton(
              canPost: _canPost,
              posting: _posting,
              onPost:  _post,
            ),
          ),
        ],
      ),
      body: Column(children: [
        // Reply context
        if (_replyTo != null)
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: WikColor.bg2,
              borderRadius: BorderRadius.circular(10),
              border: const Border.fromBorderSide(BorderSide(color: WikColor.border)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Replying to @${_replyTo!.authorHandle}',
                  style: const TextStyle(color: WikColor.accent, fontSize: 12)),
              const SizedBox(height: 4),
              Text(_replyTo!.text ?? '', style: const TextStyle(color: WikColor.text2, fontSize: 13),
                  maxLines: 2, overflow: TextOverflow.ellipsis),
            ]),
          ),

        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Avatar
              CircleAvatar(
                radius: 20,
                backgroundColor: WikColor.accent,
                child: Text(
                  (auth.username ?? address.isNotEmpty ? address[2].toUpperCase() : '?'),
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                TextField(
                  controller: _ctrl,
                  focusNode:  _focus,
                  maxLines:   null,
                  maxLength:  10000,
                  onChanged:  (_) => setState(() {}),
                  style: const TextStyle(color: WikColor.text1, fontSize: 16, height: 1.5),
                  decoration: InputDecoration(
                    hintText:    widget.replyToId != null ? 'Post your reply...' : 'What\'s happening in crypto?',
                    hintStyle:   const TextStyle(color: WikColor.text3, fontSize: 16),
                    border:      InputBorder.none,
                    counterText: '',
                    filled:      false,
                  ),
                ),
                // Tag suggestions
                if (_tags.isNotEmpty) Wrap(
                  spacing: 6,
                  children: _tags.map((t) => Chip(
                    label: Text('#$t', style: const TextStyle(color: WikColor.accent, fontSize: 12)),
                    backgroundColor: WikColor.accentBg,
                    padding: EdgeInsets.zero,
                    deleteIcon: const Icon(Icons.close, size: 14, color: WikColor.accent),
                    onDeleted: () => setState(() => _tags.remove(t)),
                  )).toList(),
                ),
                // Media preview
                if (_mediaUrl != null) _MediaPreview(
                  url:     _mediaUrl!,
                  isVideo: _mediaType == 2,
                  onRemove: () => setState(() { _mediaUrl = null; _mediaHash = null; _mediaType = 0; }),
                ),
              ])),
            ]),
          ),
        ),

        // Bottom toolbar
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: const BoxDecoration(
            border: Border(top: BorderSide(color: WikColor.border)),
          ),
          child: Row(children: [
            _ToolbarBtn(icon: Icons.image_outlined,    onTap: () => _pickMedia(false), tooltip: 'Photo'),
            _ToolbarBtn(icon: Icons.videocam_outlined,  onTap: () => _pickMedia(true),  tooltip: 'Video'),
            _ToolbarBtn(icon: Icons.tag,                onTap: _addTag,                 tooltip: 'Tag'),
            _ToolbarBtn(icon: Icons.candlestick_chart,  onTap: _shareTrade,             tooltip: 'Share trade',
                color: WikColor.gold),
            const Spacer(),
            // Char counter
            Text(
              '${10000 - _charCount}',
              style: TextStyle(
                color: _charCount > 9800 ? WikColor.red : WikColor.text3,
                fontSize: 12,
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Future<void> _pickMedia(bool video) async {
    final picker = ImagePicker();
    final XFile? file = video
        ? await picker.pickVideo(source: ImageSource.gallery)
        : await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (file == null) return;

    setState(() => _uploading = true);
    try {
      final bytes    = await file.readAsBytes();
      final mimeType = video ? 'video/mp4' : 'image/jpeg';
      final endpoint = video ? '/api/social/upload/video' : '/api/social/upload/image';

      final formData = FormData.fromMap({
        'file': MultipartFile.fromBytes(bytes, filename: file.name, contentType: DioMediaType.parse(mimeType)),
      });
      final res = await api._dio.post(endpoint, data: formData);

      setState(() {
        _mediaUrl   = res.data['url'];
        _mediaHash  = res.data['mediaHash'];
        _mediaType  = video ? 2 : 1;
        _uploading  = false;
      });
    } catch (e) {
      setState(() => _uploading = false);
      if (mounted) _showError('Upload failed: $e');
    }
  }

  Future<void> _addTag() async {
    if (_tags.length >= 5) return _showError('Maximum 5 hashtags');
    final tag = await _showTagDialog();
    if (tag != null && tag.isNotEmpty) {
      setState(() => _tags.add(tag.replaceAll('#', '').toLowerCase()));
    }
  }

  Future<String?> _showTagDialog() => showDialog<String>(
    context: context,
    builder: (ctx) {
      final ctrl = TextEditingController();
      return AlertDialog(
        backgroundColor: WikColor.bg2,
        title: const Text('Add hashtag'),
        content: TextField(
          controller: ctrl,
          decoration: const InputDecoration(hintText: 'crypto'),
          autofocus: true,
          onSubmitted: (v) => Navigator.pop(ctx, v),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('Add')),
        ],
      );
    },
  );

  Future<void> _shareTrade() async {
    // TODO: Show position picker from exchange
    _showError('Select a position from the Trade screen to share it here');
  }

  Future<void> _post() async {
    if (!_canPost) return;
    setState(() => _posting = true);

    try {
      final text = _ctrl.text.trim();

      // Step 1: Upload content to Arweave
      final auth    = ref.read(authProvider);
      final content = await SocialApi.uploadContent(text, tags: _tags, author: auth.address);
      final contentHash = content['contentHash'] as String;

      // Step 2: Call on-chain (via wallet) — WikiSocial.createPost
      // For now: show success (on-chain tx would be signed via WalletConnect/MetaMask)
      // The actual on-chain call needs wallet integration
      // contentHash + _mediaHash go on-chain as bytes32

      // Optimistically update feed
      ref.read(feedProvider.notifier).refresh();
      if (mounted) {
        context.pop();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Post submitted! Sign the transaction in your wallet.'),
            backgroundColor: WikColor.green,
          ),
        );
      }
    } catch(e) {
      setState(() => _posting = false);
      _showError('Failed to post: $e');
    }
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: WikColor.red),
    );
  }
}

// ── Sub-widgets ───────────────────────────────────────────────
class _PostButton extends StatelessWidget {
  final bool canPost, posting;
  final VoidCallback onPost;
  const _PostButton({required this.canPost, required this.posting, required this.onPost});
  @override
  Widget build(BuildContext context) => ElevatedButton(
    onPressed: canPost && !posting ? onPost : null,
    style: ElevatedButton.styleFrom(
      backgroundColor: WikColor.accent,
      disabledBackgroundColor: WikColor.accentBg,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
      minimumSize: Size.zero,
    ),
    child: posting
        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
        : const Text('Post', style: TextStyle(fontWeight: FontWeight.w700)),
  );
}

class _ToolbarBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final String tooltip;
  final Color color;
  const _ToolbarBtn({required this.icon, required this.onTap, required this.tooltip, this.color = WikColor.accent});
  @override
  Widget build(BuildContext context) => Tooltip(
    message: tooltip,
    child: IconButton(
      icon: Icon(icon, color: color, size: 22),
      onPressed: onTap,
      splashRadius: 20,
    ),
  );
}

class _MediaPreview extends StatelessWidget {
  final String url;
  final bool   isVideo;
  final VoidCallback onRemove;
  const _MediaPreview({required this.url, required this.isVideo, required this.onRemove});
  @override
  Widget build(BuildContext context) => Stack(
    children: [
      ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: isVideo
            ? Container(height: 120, color: WikColor.bg3,
                child: const Center(child: Icon(Icons.videocam, size: 40, color: WikColor.accent)))
            : Image.network(url, height: 180, width: double.infinity, fit: BoxFit.cover),
      ),
      Positioned(
        top: 6, right: 6,
        child: GestureDetector(
          onTap: onRemove,
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
            child: const Icon(Icons.close, color: Colors.white, size: 16),
          ),
        ),
      ),
    ],
  );
}
