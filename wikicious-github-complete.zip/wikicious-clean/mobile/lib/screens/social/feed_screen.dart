import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../theme.dart';
import '../../providers/providers.dart';
import '../../providers/social_providers.dart';
import '../../widgets/social/post_card.dart';

class FeedScreen extends ConsumerWidget {
  const FeedScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth  = ref.watch(authProvider);
    final feed  = ref.watch(feedProvider);

    return Scaffold(
      backgroundColor: WikColor.bg0,
      appBar: AppBar(
        backgroundColor: WikColor.bg0,
        title: Row(children: [
          // Logo
          Container(
            width: 28, height: 28,
            decoration: BoxDecoration(
              color: WikColor.accent,
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Center(
              child: Text('W', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16)),
            ),
          ),
          const SizedBox(width: 10),
          const Text('Wikicious', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        ]),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () => context.push('/notifications'),
          ),
          if (auth.address != null)
            GestureDetector(
              onTap: () => context.push('/profile/${auth.address}'),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: CircleAvatar(
                  radius: 15,
                  backgroundColor: WikColor.accent,
                  child: Text(
                    (auth.username ?? '?')[0].toUpperCase(),
                    style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ),
        ],
      ),
      body: RefreshIndicator(
        color: WikColor.accent,
        backgroundColor: WikColor.bg1,
        onRefresh: () => ref.read(feedProvider.notifier).refresh(),
        child: feed.when(
          loading: () => _FeedSkeleton(),
          error:   (e, _) => _ErrorView(message: e.toString(), onRetry: () => ref.read(feedProvider.notifier).refresh()),
          data:    (posts) => posts.isEmpty
              ? _EmptyFeed(hasAccount: auth.isLoggedIn)
              : ListView.builder(
                  itemCount: posts.length + 1,
                  itemBuilder: (ctx, i) {
                    if (i == posts.length) {
                      ref.read(feedProvider.notifier).loadMore();
                      return const Padding(
                        padding: EdgeInsets.all(20),
                        child: Center(child: CircularProgressIndicator(strokeWidth: 2, color: WikColor.accent)),
                      );
                    }
                    return PostCard(post: posts[i]);
                  },
                ),
        ),
      ),
    );
  }
}

class _EmptyFeed extends StatelessWidget {
  final bool hasAccount;
  const _EmptyFeed({required this.hasAccount});
  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.people_outline, size: 64, color: WikColor.text3),
        const SizedBox(height: 16),
        const Text('Your feed is empty', style: TextStyle(color: WikColor.text1, fontSize: 18, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Text(
          hasAccount ? 'Follow some traders to see their posts here' : 'Create an account to follow traders',
          style: const TextStyle(color: WikColor.text2, fontSize: 14),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: () => context.go('/explore'),
          child: const Text('Explore traders'),
        ),
      ]),
    ),
  );
}

class _FeedSkeleton extends StatelessWidget {
  @override
  Widget build(BuildContext context) => ListView.builder(
    itemCount: 5,
    itemBuilder: (_, __) => const _SkeletonPost(),
  );
}

class _SkeletonPost extends StatelessWidget {
  const _SkeletonPost();
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: WikColor.border))),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const _Skeleton(width: 40, height: 40, radius: 20),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _Skeleton(width: 120, height: 12),
        const SizedBox(height: 8),
        const _Skeleton(width: double.infinity, height: 12),
        const SizedBox(height: 4),
        const _Skeleton(width: 200, height: 12),
      ])),
    ]),
  );
}

class _Skeleton extends StatelessWidget {
  final double width, height, radius;
  const _Skeleton({required this.width, required this.height, this.radius = 6});
  @override
  Widget build(BuildContext context) => Container(
    width: width, height: height,
    decoration: BoxDecoration(color: WikColor.bg3, borderRadius: BorderRadius.circular(radius)),
  );
}

class _ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorView({required this.message, required this.onRetry});
  @override
  Widget build(BuildContext context) => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.error_outline, color: WikColor.red, size: 48),
      const SizedBox(height: 12),
      Text('Failed to load feed', style: const TextStyle(color: WikColor.text1, fontSize: 16)),
      const SizedBox(height: 16),
      ElevatedButton(onPressed: onRetry, child: const Text('Retry')),
    ]),
  );
}
