import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'theme.dart';
import 'providers/providers.dart';
import 'screens/shell_screen.dart';
import 'screens/auth/onboard_screen.dart';
import 'screens/auth/wallet_screen.dart';
import 'screens/trading/trade_screen.dart';
import 'screens/social/feed_screen.dart';
import 'screens/social/post_screen.dart';
import 'screens/social/compose_screen.dart';
import 'screens/social/profile_screen.dart';
import 'screens/social/explore_screen.dart';
import 'screens/social/hashtag_screen.dart';
import 'screens/social/notifications_screen.dart';
import 'screens/wallet/wallet_home_screen.dart';
import 'screens/leaderboard_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const ProviderScope(child: WikiciousApp()));
}

final _router = GoRouter(
  initialLocation: '/feed',
  routes: [
    GoRoute(path: '/onboard', builder: (_, __) => const OnboardScreen()),
    GoRoute(path: '/wallet-setup', builder: (_, __) => const WalletSetupScreen()),
    ShellRoute(
      builder: (ctx, state, child) => ShellScreen(child: child),
      routes: [
        GoRoute(path: '/feed',          builder: (_, __) => const FeedScreen()),
        GoRoute(path: '/explore',       builder: (_, __) => const ExploreScreen()),
        GoRoute(path: '/trade',         builder: (_, s)  => TradeScreen(symbol: s.uri.queryParameters['symbol'])),
        GoRoute(path: '/wallet',        builder: (_, __) => const WalletHomeScreen()),
        GoRoute(path: '/leaderboard',   builder: (_, __) => const LeaderboardScreen()),
      ],
    ),
    GoRoute(path: '/post/:id',          builder: (_, s)  => PostDetailScreen(postId: int.parse(s.pathParameters['id']!))),
    GoRoute(path: '/compose',           builder: (_, s)  => ComposeScreen(replyToId: int.tryParse(s.uri.queryParameters['replyTo'] ?? ''))),
    GoRoute(path: '/profile/:address',  builder: (_, s)  => ProfileScreen(address: s.pathParameters['address']!)),
    GoRoute(path: '/hashtag/:tag',      builder: (_, s)  => HashtagScreen(tag: s.pathParameters['tag']!)),
    GoRoute(path: '/notifications',     builder: (_, __) => const NotificationsScreen()),
  ],
);

class WikiciousApp extends ConsumerWidget {
  const WikiciousApp({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp.router(
      title: 'Wikicious',
      theme: wikTheme(),
      routerConfig: _router,
      debugShowCheckedModeBanner: false,
    );
  }
}
