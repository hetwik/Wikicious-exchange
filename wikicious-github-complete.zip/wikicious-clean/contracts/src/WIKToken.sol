// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Votes.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

/// @title WIK Token — Wikicious governance, fee discount, and staking token
contract WIKToken is ERC20, ERC20Burnable, ERC20Permit, ERC20Votes, Ownable {
    uint256 public constant MAX_SUPPLY = 1_000_000_000 * 1e18; // 1B WIK

    // Fee discount tiers based on WIK held
    struct Tier {
        uint256 minWIK;      // minimum WIK to hold
        uint256 makerDiscount; // bps discount on maker fee
        uint256 takerDiscount; // bps discount on taker fee
    }

    Tier[5] public tiers;
    mapping(address => bool) public minters;

    event MinterSet(address indexed minter, bool enabled);

    constructor(address initialOwner)
        ERC20("Wikicious", "WIK")
        ERC20Permit("Wikicious")
        Ownable(initialOwner)
    {
        // Fee discount tiers
        tiers[0] = Tier(0,               0,   0);
        tiers[1] = Tier(1_000  * 1e18,  10,  5);  // 1K WIK  → 10% maker, 5% taker discount
        tiers[2] = Tier(10_000 * 1e18,  20, 10);  // 10K WIK → 20/10
        tiers[3] = Tier(50_000 * 1e18,  30, 20);  // 50K WIK → 30/20
        tiers[4] = Tier(100_000* 1e18,  50, 30);  // 100K WIK→ 50/30

        // Mint initial supply to owner for distribution
        _mint(initialOwner, 200_000_000 * 1e18); // 20% to team/treasury
    }

    function setMinter(address minter, bool enabled) external onlyOwner {
        minters[minter] = enabled;
        emit MinterSet(minter, enabled);
    }

    function mint(address to, uint256 amount) external {
        require(minters[msg.sender], "WIK: not minter");
        require(totalSupply() + amount <= MAX_SUPPLY, "WIK: max supply exceeded");
        _mint(to, amount);
    }

    /// @notice Get fee discount bps for a holder
    function getDiscount(address user) external view returns (uint256 makerDiscount, uint256 takerDiscount) {
        uint256 bal = balanceOf(user);
        for (uint256 i = 4; i > 0; i--) {
            if (bal >= tiers[i].minWIK) {
                return (tiers[i].makerDiscount, tiers[i].takerDiscount);
            }
        }
        return (0, 0);
    }

    // Required overrides
    function _update(address from, address to, uint256 value)
        internal override(ERC20, ERC20Votes) { super._update(from, to, value); }

    function nonces(address owner)
        public view override(ERC20Permit, Nonces) returns (uint256) { return super.nonces(owner); }
}
