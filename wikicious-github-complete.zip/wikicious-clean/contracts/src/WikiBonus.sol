// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/access/Ownable2Step.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

/// @title WikiBonus — Virtual trading credit system
///
/// ╔══════════════════════════════════════════════════════════════╗
/// ║  HOW THE BONUS WORKS                                         ║
/// ║                                                              ║
/// ║  Bonuses are VIRTUAL CREDIT — not real USDC.                 ║
/// ║  They exist as accounting units in this contract.            ║
/// ║  They can ONLY be used as collateral for WikiPerp trades.    ║
/// ║  The principal ($50/$100/$200) NEVER leaves the platform.    ║
/// ║                                                              ║
/// ║  Profits made WITH bonus credit → 100% real, withdrawable.  ║
/// ║  Bonus principal → stays locked, recycles back to treasury.  ║
/// ║                                                              ║
/// ║  Fee on bonus trades: 0.10% (double normal rate)             ║
/// ║  Expiry: 90 days from grant (or from last trade)             ║
/// ╚══════════════════════════════════════════════════════════════╝
///
/// BONUS TYPES:
///   SIGNUP          $50   — wallet creation + anti-sybil check
///   DEPOSIT_MATCH   $100  — first deposit of $100+ USDC
///   REFERRAL        $50   — per referred friend who signs up
///   REFERRAL_STREAK $200  — milestone for 5 successful referrals
///
/// REFERRAL REVENUE SHARE:
///   Referrer earns 10% of referee's trading fees FOREVER (real USDC)
///   Paid in real-time when WikiPerp collects fees
///   Tracked on-chain, claimable any time
///
/// ANTI-ABUSE:
///   1 bonus per wallet address (checked via tx history)
///   Wallet must hold ≥ 0.001 ETH at signup (proves real user, ~$2)
///   Referral only counts after referee makes their first real deposit
///   No bonus → bonus chaining (can't refer yourself)
///   Blacklist for detected abuse patterns

interface IWikiPerp {
    function openPositionWithBonus(
        address trader,
        uint256 bonusCollateral,
        uint256 realCollateral,
        uint256 marketIndex,
        bool    isLong,
        uint256 size,
        uint256 minPrice,
        uint256 maxPrice,
        uint256 expiry
    ) external returns (uint256 posId);
}

interface IWikiVault {
    function totalMargin(address user) external view returns (uint256);
    function deposit(address user, uint256 amount) external;
}

contract WikiBonus is Ownable2Step, ReentrancyGuard, Pausable {
    using SafeERC20 for IERC20;

    IERC20 public immutable USDC;
    address public perpContract;
    address public vaultContract;
    address public treasury;       // receives expired/burned bonus credit

    // ── Bonus amounts (USDC, 6 dec) ────────────────────────────────────────
    uint256 public bonusSignup         = 50  * 1e6;   // $50
    uint256 public bonusDepositMatch   = 100 * 1e6;   // $100
    uint256 public bonusReferral       = 50  * 1e6;   // $50 per referral
    uint256 public bonusReferralStreak = 200 * 1e6;   // $200 at 5 referrals
    uint256 public referralStreakCount = 5;            // referrals needed for streak bonus

    uint256 public constant BONUS_FEE_BPS    = 10;    // 0.10% on bonus trades
    uint256 public constant NORMAL_FEE_BPS   = 5;     // 0.05% normal
    uint256 public constant REFERRAL_REV_BPS = 1000;  // 10% of referee fees to referrer
    uint256 public constant BONUS_EXPIRY     = 90 days;
    uint256 public constant MIN_ETH_BALANCE  = 0.001 ether;
    uint256 public constant MIN_DEPOSIT_FOR_MATCH = 100 * 1e6; // $100 min deposit
    uint256 public constant BPS              = 10000;

    // ── User bonus account ─────────────────────────────────────────────────
    struct BonusAccount {
        uint256 creditBalance;      // current virtual credit (USDC units)
        uint256 totalGranted;       // lifetime bonus received
        uint256 totalUsedInTrades;  // how much credit used as collateral
        uint256 feesGenerated;      // total fees paid while using bonus
        uint256 expiresAt;          // 90 days from last grant
        bool    signupClaimed;
        bool    depositMatchClaimed;
        uint256 referralCount;      // successful referrals made
        uint256 referralStreaksClaimed;
        address referredBy;         // who referred this user (address(0) if none)
        bool    isBlacklisted;
        uint256 createdAt;
    }

    // ── Referral tracking ──────────────────────────────────────────────────
    struct ReferralStats {
        uint256 totalReferrals;      // total friends referred
        uint256 qualifiedReferrals;  // friends who made first deposit
        uint256 totalBonusEarned;    // total referral bonus credited
        uint256 revenueShareEarned;  // total real USDC earned from fee share
        uint256 revenueShareClaimed; // amount claimed
        address[] referees;          // list of referred addresses
    }

    mapping(address => BonusAccount)  public bonusAccounts;
    mapping(address => ReferralStats) public referralStats;
    mapping(bytes32 => address)       public referralCodes;  // code → owner
    mapping(address => bytes32)       public userReferralCode;// owner → code
    mapping(address => bool)          public hasDeposited;    // first deposit tracker
    mapping(address => uint256)       public claimableRevShare; // real USDC owed to referrer

    // Platform totals
    uint256 public totalBonusIssued;
    uint256 public totalBonusExpired;
    uint256 public totalBonusFees;
    uint256 public totalRevSharePaid;
    uint256 public totalUsers;

    // Events
    event BonusGranted(address indexed user, uint256 amount, string reason);
    event BonusUsed(address indexed user, uint256 amount, uint256 feeCharged);
    event BonusExpired(address indexed user, uint256 amount);
    event ReferralCodeCreated(address indexed user, bytes32 code);
    event ReferralRegistered(address indexed referrer, address indexed referee, bytes32 code);
    event ReferralQualified(address indexed referrer, address indexed referee);
    event RevShareEarned(address indexed referrer, address indexed referee, uint256 amount);
    event RevShareClaimed(address indexed referrer, uint256 amount);
    event UserBlacklisted(address indexed user, string reason);

    constructor(address usdc, address _treasury, address owner) Ownable(owner) {
        USDC     = IERC20(usdc);
        treasury = _treasury;
        // Fund the contract with protocol USDC to back bonus credit
        // This is the treasury's "virtual reserve" — never paid out as USDC
        // only used as accounting credit for trade collateral
    }

    // ── Registration + signup bonus ────────────────────────────────────────
    /// @notice Register new user. Grants $50 signup bonus.
    /// @param  referralCode  Optional referral code from another user
    function register(bytes32 referralCode) external nonReentrant whenNotPaused {
        require(!bonusAccounts[msg.sender].signupClaimed, "Bonus: already registered");
        require(!bonusAccounts[msg.sender].isBlacklisted,  "Bonus: blacklisted");

        // Anti-sybil: wallet must hold ETH (proves real user)
        require(msg.sender.balance >= MIN_ETH_BALANCE, "Bonus: need 0.001 ETH in wallet");

        uint256 ts = block.timestamp;
        totalUsers++;

        // Init account
        bonusAccounts[msg.sender].createdAt   = ts;
        bonusAccounts[msg.sender].signupClaimed = true;

        // Generate referral code for this user
        bytes32 myCode = _genCode(msg.sender);
        userReferralCode[msg.sender] = myCode;
        referralCodes[myCode]        = msg.sender;
        emit ReferralCodeCreated(msg.sender, myCode);

        // Process incoming referral
        if (referralCode != bytes32(0)) {
            address referrer = referralCodes[referralCode];
            if (referrer != address(0) && referrer != msg.sender
                && !bonusAccounts[referrer].isBlacklisted)
            {
                bonusAccounts[msg.sender].referredBy = referrer;
                referralStats[referrer].totalReferrals++;
                referralStats[referrer].referees.push(msg.sender);
                emit ReferralRegistered(referrer, msg.sender, referralCode);
            }
        }

        // Grant $50 signup bonus
        _grantBonus(msg.sender, bonusSignup, "signup");
        emit BonusGranted(msg.sender, bonusSignup, "signup");
    }

    // ── First deposit match ────────────────────────────────────────────────
    /// @notice Called by WikiVault when user makes first deposit ≥ $100
    function onFirstDeposit(address user, uint256 depositAmount)
        external nonReentrant
    {
        require(msg.sender == vaultContract, "Bonus: only vault");
        if (bonusAccounts[user].depositMatchClaimed) return;
        if (depositAmount < MIN_DEPOSIT_FOR_MATCH) return;
        if (!bonusAccounts[user].signupClaimed) return; // must be registered

        bonusAccounts[user].depositMatchClaimed = true;
        hasDeposited[user] = true;

        // Grant $100 deposit match bonus
        _grantBonus(user, bonusDepositMatch, "deposit_match");
        emit BonusGranted(user, bonusDepositMatch, "deposit_match");

        // Qualify the referral — referrer gets their bonus + rev share unlocks
        address referrer = bonusAccounts[user].referredBy;
        if (referrer != address(0)) {
            _qualifyReferral(referrer, user);
        }
    }

    // ── Qualify referral after friend deposits ─────────────────────────────
    function _qualifyReferral(address referrer, address referee) internal {
        ReferralStats storage rs = referralStats[referrer];
        rs.qualifiedReferrals++;
        emit ReferralQualified(referrer, referee);

        // Grant referrer their $50 referral bonus
        _grantBonus(referrer, bonusReferral, "referral");
        emit BonusGranted(referrer, bonusReferral, "referral");
        rs.totalBonusEarned += bonusReferral;

        // Check streak milestone (every 5 qualified referrals)
        uint256 streaksEarnable = rs.qualifiedReferrals / referralStreakCount;
        if (streaksEarnable > rs.referralStreaksClaimed) {  // Renamed field access to match struct
            uint256 newStreaks = streaksEarnable - bonusAccounts[referrer].referralStreaksClaimed;
            bonusAccounts[referrer].referralStreaksClaimed += newStreaks;
            uint256 streakBonus = newStreaks * bonusReferralStreak;
            _grantBonus(referrer, streakBonus, "referral_streak");
            emit BonusGranted(referrer, streakBonus, "referral_streak");
            rs.totalBonusEarned += streakBonus;
        }
    }

    // ── Record fee from bonus trade (called by WikiPerp) ──────────────────
    /// @notice WikiPerp calls this when a position using bonus credit pays fees
    /// @param trader     The trader
    /// @param bonusUsed  How much bonus credit was used as collateral
    /// @param tradeSize  Full notional size of the trade
    function recordBonusTradeFee(
        address trader,
        uint256 bonusUsed,
        uint256 tradeSize
    ) external nonReentrant returns (uint256 fee) {
        require(msg.sender == perpContract, "Bonus: only perp");
        BonusAccount storage acc = bonusAccounts[trader];
        if (acc.creditBalance == 0 || acc.isBlacklisted) return 0;

        // Double fee on bonus trades
        fee = tradeSize * BONUS_FEE_BPS / BPS;
        acc.feesGenerated    += fee;
        acc.totalUsedInTrades += bonusUsed;
        totalBonusFees        += fee;

        emit BonusUsed(trader, bonusUsed, fee);

        // Revenue share: 10% of this fee goes to referrer (real USDC)
        address referrer = acc.referredBy;
        if (referrer != address(0) && !bonusAccounts[referrer].isBlacklisted) {
            uint256 share = fee * REFERRAL_REV_BPS / BPS;
            claimableRevShare[referrer]              += share;
            referralStats[referrer].revenueShareEarned += share;
            totalRevSharePaid                        += share;
            emit RevShareEarned(referrer, trader, share);
        }
    }

    // ── Record fee from NORMAL trade for rev share ─────────────────────────
    /// @notice Called by WikiPerp on every trade — checks if trader was referred
    function recordNormalTradeFee(address trader, uint256 fee)
        external nonReentrant
    {
        require(msg.sender == perpContract, "Bonus: only perp");
        address referrer = bonusAccounts[trader].referredBy;
        if (referrer == address(0)) return;
        if (!hasDeposited[trader]) return; // only qualified referrals
        if (bonusAccounts[referrer].isBlacklisted) return;

        uint256 share = fee * REFERRAL_REV_BPS / BPS;
        claimableRevShare[referrer]               += share;
        referralStats[referrer].revenueShareEarned += share;
        totalRevSharePaid                         += share;
        emit RevShareEarned(referrer, trader, share);
    }

    // ── Claim revenue share (real USDC) ───────────────────────────────────
    function claimRevShare() external nonReentrant whenNotPaused {
        uint256 amount = claimableRevShare[msg.sender];
        require(amount > 0, "Bonus: nothing to claim");
        // CEI
        claimableRevShare[msg.sender] = 0;
        referralStats[msg.sender].revenueShareClaimed += amount;

        // Transfer real USDC from treasury
        USDC.safeTransferFrom(treasury, msg.sender, amount);
        emit RevShareClaimed(msg.sender, amount);
    }

    // ── WikiPerp queries bonus balance ────────────────────────────────────
    function getBonusBalance(address user) external view returns (uint256) {
        BonusAccount storage acc = bonusAccounts[user];
        if (acc.isBlacklisted) return 0;
        if (acc.expiresAt > 0 && block.timestamp > acc.expiresAt) return 0;
        return acc.creditBalance;
    }

    // ── Expire stale bonuses (callable by anyone / keeper) ────────────────
    function expireBonus(address user) external nonReentrant {
        BonusAccount storage acc = bonusAccounts[user];
        if (acc.creditBalance == 0) return;
        if (acc.expiresAt == 0 || block.timestamp <= acc.expiresAt) return;

        uint256 expired = acc.creditBalance;
        acc.creditBalance  = 0;
        totalBonusExpired += expired;
        // Expired credit returns to treasury accounting (never was real USDC)
        emit BonusExpired(user, expired);
    }

    // ── Referral code helpers ──────────────────────────────────────────────
    function getReferralCode(address user) external view returns (bytes32) {
        return userReferralCode[user];
    }

    function getReferralLink(address user) external view returns (string memory) {
        bytes32 code = userReferralCode[user];
        // Returns hex string — frontend builds full URL
        return _bytes32ToHex(code);
    }

    function resolveCode(bytes32 code) external view returns (address referrer) {
        return referralCodes[code];
    }

    // ── Views ──────────────────────────────────────────────────────────────
    function getBonusAccount(address user) external view returns (
        uint256 creditBalance,
        uint256 totalGranted,
        uint256 feesGenerated,
        uint256 expiresAt,
        uint256 daysLeft,
        bool    signupClaimed,
        bool    depositMatchClaimed,
        bool    isExpired
    ) {
        BonusAccount storage acc = bonusAccounts[user];
        creditBalance      = acc.creditBalance;
        totalGranted       = acc.totalGranted;
        feesGenerated      = acc.feesGenerated;
        expiresAt          = acc.expiresAt;
        daysLeft           = acc.expiresAt > block.timestamp
            ? (acc.expiresAt - block.timestamp) / 1 days : 0;
        signupClaimed      = acc.signupClaimed;
        depositMatchClaimed = acc.depositMatchClaimed;
        isExpired          = acc.expiresAt > 0 && block.timestamp > acc.expiresAt;
    }

    function getReferralStats(address user) external view returns (
        uint256 totalReferrals,
        uint256 qualifiedReferrals,
        uint256 totalBonusEarned,
        uint256 revenueShareEarned,
        uint256 pendingRevShare,
        bytes32 myCode
    ) {
        ReferralStats storage rs = referralStats[user];
        totalReferrals     = rs.totalReferrals;
        qualifiedReferrals = rs.qualifiedReferrals;
        totalBonusEarned   = rs.totalBonusEarned;
        revenueShareEarned = rs.revenueShareEarned;
        pendingRevShare    = claimableRevShare[user];
        myCode             = userReferralCode[user];
    }

    function platformStats() external view returns (
        uint256 users,
        uint256 bonusIssued,
        uint256 bonusExpired,
        uint256 bonusFees,
        uint256 revSharePaid,
        uint256 activeBonus   // rough estimate
    ) {
        users        = totalUsers;
        bonusIssued  = totalBonusIssued;
        bonusExpired = totalBonusExpired;
        bonusFees    = totalBonusFees;
        revSharePaid = totalRevSharePaid;
        activeBonus  = totalBonusIssued > totalBonusExpired
            ? totalBonusIssued - totalBonusExpired : 0;
    }

    // ── Internal ───────────────────────────────────────────────────────────
    function _grantBonus(address user, uint256 amount, string memory) internal {
        BonusAccount storage acc = bonusAccounts[user];
        acc.creditBalance  += amount;
        acc.totalGranted   += amount;
        // Reset 90-day expiry on each new grant
        acc.expiresAt = block.timestamp + BONUS_EXPIRY;
        totalBonusIssued  += amount;
        acc.referralCount  = referralStats[user].qualifiedReferrals; // sync
    }

    function _genCode(address user) internal view returns (bytes32) {
        return keccak256(abi.encodePacked(user, block.timestamp, block.prevrandao));
    }

    function _bytes32ToHex(bytes32 b) internal pure returns (string memory) {
        bytes memory hexChars = "0123456789abcdef";
        bytes memory result   = new bytes(16); // first 8 bytes = 16 hex chars (enough for URL)
        for (uint i = 0; i < 8; i++) {
            result[i*2]   = hexChars[uint8(b[i] >> 4)];
            result[i*2+1] = hexChars[uint8(b[i] & 0x0f)];
        }
        return string(result);
    }

    // ── Admin ──────────────────────────────────────────────────────────────
    function setPerpContract(address p)  external onlyOwner { perpContract  = p; }
    function setVaultContract(address v) external onlyOwner { vaultContract = v; }
    function setTreasury(address t)      external onlyOwner { treasury      = t; }
    function setBonusAmounts(
        uint256 signup, uint256 match, uint256 referral, uint256 streak
    ) external onlyOwner {
        bonusSignup         = signup;
        bonusDepositMatch   = match;
        bonusReferral       = referral;
        bonusReferralStreak = streak;
    }
    function blacklist(address user, string calldata reason) external onlyOwner {
        bonusAccounts[user].isBlacklisted = true;
        emit UserBlacklisted(user, reason);
    }
    function unblacklist(address user) external onlyOwner {
        bonusAccounts[user].isBlacklisted = false;
    }
    // Admin can manually grant bonus (partnerships, campaigns)
    function adminGrant(address user, uint256 amount, string calldata reason) external onlyOwner {
        require(amount <= 1000 * 1e6, "Bonus: max $1000 admin grant");
        _grantBonus(user, amount, reason);
        emit BonusGranted(user, amount, reason);
    }
    function pause()   external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }
}
