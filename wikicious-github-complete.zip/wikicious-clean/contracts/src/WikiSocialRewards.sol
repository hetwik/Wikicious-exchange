// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/access/Ownable2Step.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

interface IWikiSocial {
    function getPost(uint256 id) external view returns (
        uint256, address, uint8, bytes32, bytes32, uint8,
        uint256, uint256, uint256, uint256, uint256, uint256, uint256, uint256, bool, uint256, bool
    );
    function totalPosts() external view returns (uint256);
}

/// @title WikiSocialRewards — WIK rewards for social engagement
///
/// TWO REWARD STREAMS:
///
/// Stream 1 — Instant micro-rewards (per action):
///   Post created  → 1 WIK to author
///   Post liked    → 0.5 WIK to author, 0.1 WIK to liker
///   Comment       → 0.3 WIK to author, 0.2 WIK to commenter
///   Repost        → 0.2 WIK to original author
///   New follow    → 0.1 WIK to followed
///
/// Stream 2 — Daily engagement pool:
///   Every 24h, a configurable WIK pool is distributed
///   Split proportionally by engagement score across all posts that day
///   Top post of the day gets a 2x bonus multiplier
///   Trader-verified authors earn 1.5x multiplier
///
/// INTEGRATION:
///   WikiSocial calls onLike/onComment/etc. → triggers instant rewards
///   Keeper calls distributeDailyPool() every 24h → distributes pool
///   Same WIK token as used for trading fee discounts and staking

contract WikiSocialRewards is Ownable2Step, ReentrancyGuard, Pausable {
    using SafeERC20 for IERC20;

    IERC20     public immutable WIK;
    IWikiSocial public           social;

    // ── Reward rates (in WIK, 18 decimals) ────────────────────────────────
    uint256 public rewardPostCreate  = 1   * 1e18;  // 1 WIK per post
    uint256 public rewardLikeAuthor  = 5e17;        // 0.5 WIK to author on like
    uint256 public rewardLikeLiker   = 1e17;        // 0.1 WIK to liker
    uint256 public rewardComment     = 3e17;        // 0.3 WIK to author on comment
    uint256 public rewardCommenter   = 2e17;        // 0.2 WIK to commenter
    uint256 public rewardRepost      = 2e17;        // 0.2 WIK to original author
    uint256 public rewardFollow      = 1e17;        // 0.1 WIK to followed

    // ── Daily pool ─────────────────────────────────────────────────────────
    uint256 public dailyPoolSize     = 10_000 * 1e18; // 10,000 WIK per day
    uint256 public lastDistribution;
    uint256 public currentDay;

    // Per-day post engagement tracking
    mapping(uint256 => mapping(uint256 => uint256)) public dayPostScore; // day → postId → score
    mapping(uint256 => uint256[])                   public dayPosts;     // day → postIds active today
    mapping(uint256 => mapping(address => uint256)) public dayAuthorScore; // day → author → cumulative score
    mapping(uint256 => bool)                        public dayDistributed;

    // Claimable WIK balances (pull model — safer than push)
    mapping(address => uint256) public claimable;
    mapping(address => uint256) public totalEarned;
    mapping(address => uint256) public totalClaimed;

    // Rate limiting — prevent reward farming
    mapping(address => uint256) public lastActionTs;
    mapping(address => uint256) public actionsToday;
    mapping(address => uint256) public lastActionDay;
    uint256 public constant MAX_REWARD_ACTIONS_DAY = 200;
    uint256 public constant MIN_ACTION_INTERVAL    = 1; // 1 second min between actions

    // Caps
    uint256 public maxDailyEarningPerUser = 500 * 1e18; // 500 WIK/day max
    mapping(address => uint256) public dailyEarned;
    mapping(address => uint256) public dailyEarnedDay;

    address public socialContract; // only WikiSocial can call onX functions

    // ── Events ─────────────────────────────────────────────────────────────
    event RewardEarned(address indexed user, uint256 amount, string reason);
    event DailyPoolDistributed(uint256 day, uint256 totalWIK, uint256 posts);
    event RewardClaimed(address indexed user, uint256 amount);
    event RatesUpdated();
    event DailyPoolSizeUpdated(uint256 newSize);

    constructor(address wik, address _social, address owner) Ownable(owner) {
        WIK            = IERC20(wik);
        social         = IWikiSocial(_social);
        socialContract = _social;
        lastDistribution = block.timestamp;
        currentDay       = block.timestamp / 86400;
    }

    modifier onlySocial() {
        require(msg.sender == socialContract, "Rewards: only social contract");
        _;
    }

    // ── Called by WikiSocial on each action ───────────────────────────────
    function onPostCreated(uint256 postId, address author) external onlySocial whenNotPaused {
        _reward(author, rewardPostCreate, "post");
        // Track for daily pool
        uint256 day = block.timestamp / 86400;
        dayPosts[day].push(postId);
        dayPostScore[day][postId] = 1; // starts at 1 point
        dayAuthorScore[day][author] += 1;
    }

    function onLike(uint256 postId, address liker, address author) external onlySocial whenNotPaused {
        if (liker == author) return; // no self-farming
        _reward(author, rewardLikeAuthor, "like_received");
        _reward(liker,  rewardLikeLiker,  "like_given");
        // Boost post score for daily pool
        uint256 day = block.timestamp / 86400;
        dayPostScore[day][postId]    += 10;
        dayAuthorScore[day][author]  += 10;
    }

    function onComment(uint256 postId, address commenter, address author) external onlySocial whenNotPaused {
        if (commenter == author) return;
        _reward(author,    rewardComment,   "comment_received");
        _reward(commenter, rewardCommenter, "comment_given");
        uint256 day = block.timestamp / 86400;
        dayPostScore[day][postId]    += 5;
        dayAuthorScore[day][author]  += 5;
    }

    function onRepost(uint256 postId, address reposter, address author) external onlySocial whenNotPaused {
        if (reposter == author) return;
        _reward(author, rewardRepost, "repost");
        uint256 day = block.timestamp / 86400;
        dayPostScore[day][postId]   += 3;
        dayAuthorScore[day][author] += 3;
    }

    function onFollow(address follower, address followed) external onlySocial whenNotPaused {
        if (follower == followed) return;
        _reward(followed, rewardFollow, "new_follower");
    }

    // ── Daily pool distribution ───────────────────────────────────────────
    /// @notice Distribute the daily WIK pool. Anyone can call after 24h.
    /// @dev    Keeper calls this but it's permissionless — can't be censored
    function distributeDailyPool() external nonReentrant whenNotPaused {
        uint256 day = block.timestamp / 86400;
        require(day > currentDay, "Rewards: too early");
        require(!dayDistributed[currentDay], "Rewards: already distributed");

        uint256 distribDay = currentDay;
        currentDay         = day;
        dayDistributed[distribDay] = true;
        lastDistribution   = block.timestamp;

        uint256[] storage todayPosts = dayPosts[distribDay];
        if (todayPosts.length == 0) return;

        // Check contract has enough WIK
        uint256 available = WIK.balanceOf(address(this));
        uint256 poolAmt   = available >= dailyPoolSize ? dailyPoolSize : available;
        if (poolAmt == 0) return;

        // Calculate total engagement score for the day
        uint256 totalScore = 0;
        for (uint i = 0; i < todayPosts.length; i++) {
            totalScore += dayPostScore[distribDay][todayPosts[i]];
        }
        if (totalScore == 0) return;

        // Find top post of the day (2x bonus)
        uint256 topPost; uint256 topScore;
        for (uint i = 0; i < todayPosts.length; i++) {
            uint256 s = dayPostScore[distribDay][todayPosts[i]];
            if (s > topScore) { topScore = s; topPost = todayPosts[i]; }
        }

        // Distribute proportionally to post authors
        mapping(address => uint256) storage authorRewards = dayAuthorScore[distribDay];
        // Re-aggregate by author with multipliers
        // (done off-chain for gas efficiency — keeper submits author→amount mapping)
        // For on-chain simplicity: distribute based on author cumulative score
        uint256 distributed = 0;
        for (uint i = 0; i < todayPosts.length && distributed < poolAmt; i++) {
            uint256 pid    = todayPosts[i];
            uint256 score  = dayPostScore[distribDay][pid];
            if (score == 0) continue;

            // Fetch author from social contract
            (,address author,,,,,,,,,,,,,,,, ) = _getPostAuthor(pid);

            // Multipliers
            uint256 mult = 100; // base 100 = 1x
            if (pid == topPost) mult = 200; // top post 2x

            uint256 share = poolAmt * score * mult / (totalScore * 100);
            if (distributed + share > poolAmt) share = poolAmt - distributed;

            claimable[author] += share;
            totalEarned[author] += share;
            distributed += share;
            emit RewardEarned(author, share, "daily_pool");
        }

        emit DailyPoolDistributed(distribDay, distributed, todayPosts.length);
    }

    /// @notice Alternative: owner submits pre-computed distribution (gas efficient)
    /// @dev    Owner calculates off-chain, submits on-chain. Verifiable by anyone.
    function distributePoolBatch(
        uint256         day,
        address[] calldata recipients,
        uint256[] calldata amounts
    ) external onlyOwner nonReentrant {
        require(!dayDistributed[day], "Rewards: already distributed");
        require(recipients.length == amounts.length, "Rewards: length mismatch");
        require(recipients.length <= 500, "Rewards: too many");
        dayDistributed[day] = true;

        uint256 total;
        for (uint i = 0; i < amounts.length; i++) total += amounts[i];
        require(WIK.balanceOf(address(this)) >= total, "Rewards: insufficient WIK");

        for (uint i = 0; i < recipients.length; i++) {
            if (amounts[i] == 0) continue;
            claimable[recipients[i]]    += amounts[i];
            totalEarned[recipients[i]]  += amounts[i];
            emit RewardEarned(recipients[i], amounts[i], "daily_pool");
        }
        emit DailyPoolDistributed(day, total, recipients.length);
    }

    // ── Claim ──────────────────────────────────────────────────────────────
    function claim() external nonReentrant whenNotPaused {
        uint256 amount = claimable[msg.sender];
        require(amount > 0, "Rewards: nothing to claim");
        // [CEI] clear before transfer
        claimable[msg.sender]    = 0;
        totalClaimed[msg.sender] += amount;
        WIK.safeTransfer(msg.sender, amount);
        emit RewardClaimed(msg.sender, amount);
    }

    function claimable_(address user) external view returns (uint256) { return claimable[user]; }

    // ── Admin ──────────────────────────────────────────────────────────────
    function setRates(
        uint256 postCreate, uint256 likeAuthor, uint256 likeLiker,
        uint256 cmt, uint256 cmter, uint256 rp, uint256 fol
    ) external onlyOwner {
        rewardPostCreate = postCreate; rewardLikeAuthor  = likeAuthor;
        rewardLikeLiker  = likeLiker;  rewardComment     = cmt;
        rewardCommenter  = cmter;      rewardRepost      = rp;
        rewardFollow     = fol;
        emit RatesUpdated();
    }

    function setDailyPoolSize(uint256 size) external onlyOwner {
        dailyPoolSize = size;
        emit DailyPoolSizeUpdated(size);
    }

    function setMaxDailyEarning(uint256 max) external onlyOwner { maxDailyEarningPerUser = max; }
    function setSocialContract(address s)    external onlyOwner { socialContract = s; }

    function fundRewards(uint256 amount) external {
        WIK.safeTransferFrom(msg.sender, address(this), amount);
    }

    function withdrawExcess(uint256 amount) external onlyOwner {
        WIK.safeTransfer(owner(), amount);
    }

    function pause()   external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    // ── Internal ───────────────────────────────────────────────────────────
    function _reward(address user, uint256 amount, string memory reason) internal {
        if (user == address(0) || amount == 0) return;

        // Daily earning cap
        uint256 day = block.timestamp / 86400;
        if (dailyEarnedDay[user] != day) {
            dailyEarnedDay[user] = day;
            dailyEarned[user]    = 0;
        }
        if (dailyEarned[user] >= maxDailyEarningPerUser) return;

        // Action rate limit
        if (lastActionDay[user] != day) {
            lastActionDay[user]  = day;
            actionsToday[user]   = 0;
        }
        if (actionsToday[user] >= MAX_REWARD_ACTIONS_DAY) return;
        actionsToday[user]++;

        // Cap to daily limit
        uint256 remaining = maxDailyEarningPerUser - dailyEarned[user];
        uint256 actual    = amount > remaining ? remaining : amount;

        // Check contract has WIK
        if (WIK.balanceOf(address(this)) < actual) return;

        claimable[user]    += actual;
        totalEarned[user]  += actual;
        dailyEarned[user]  += actual;

        emit RewardEarned(user, actual, reason);
    }

    function _getPostAuthor(uint256 postId) internal view returns (
        uint256, address author, uint8, bytes32, bytes32, uint8,
        uint256, uint256, uint256, uint256, uint256, uint256, uint256, uint256, bool, uint256, bool
    ) {
        return social.getPost(postId);
    }
}
