// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/access/Ownable2Step.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

/// @title WikiPropEval — Prop firm evaluation via SIMULATED paper trading
///
/// ╔══════════════════════════════════════════════════════╗
/// ║  ZERO CAPITAL AT RISK DURING EVALUATION              ║
/// ║                                                      ║
/// ║  Eval trades are 100% simulated (paper trades).      ║
/// ║  No real positions opened on WikiPerp.               ║
/// ║  No pool or protocol capital touched.                ║
/// ║  Only the eval fee moves — everything else is        ║
/// ║  tracked as numbers on-chain using oracle prices.    ║
/// ║                                                      ║
/// ║  Real money only enters when trader PASSES eval      ║
/// ║  and graduates to a WikiPropFunded account.          ║
/// ╚══════════════════════════════════════════════════════╝
///
/// SIMULATION MODEL:
///   openSimTrade()  → snapshots oracle price as entry
///   closeSimTrade() → snapshots oracle price as exit
///   pnl = size × Δprice / entryPrice (long) or reverse (short)
///   Balance updated → drawdown rules enforced → pass/fail
///
/// THREE TIERS:
///   Tier 1 — 1-Phase:  0.5% fee | 8% target | 4% daily DD | 8% total DD | 30 days
///   Tier 2 — 2-Phase:  0.4% fee | 8%+5%     | 5% daily DD | 10% total DD | 30+60 days
///   Tier 3 — Instant:  3.0% fee | no eval   | 3% daily DD | 6% total DD  | no limit
///
/// FUNDED ACCOUNT PROFIT SPLIT (after passing):
///   Initial:         70% tier1 / 80% tier2 / 60% tier3
///   2× cumulative:   80%
///   5× cumulative:   90% (max)

interface IWikiOracle {
    function getPrice(uint256 marketIndex) external view returns (uint256 price, uint256 timestamp);
}

interface IWikiPropFunded {
    function createFundedAccount(address trader, uint256 accountSize, uint8 tier, uint256 initialSplitBps)
        external returns (uint256 accountId);
}

interface IWikiPropPool {
    function receiveEvalFee(uint256 amount) external;
}

contract WikiPropEval is Ownable2Step, ReentrancyGuard, Pausable {
    using SafeERC20 for IERC20;

    IERC20  public immutable USDC;
    address public oracle;
    address public fundedContract;
    address public propPool;
    address public feeRecipient;

    uint256 public constant BPS            = 10000;
    uint256 public constant POOL_FEE_SHARE = 7000; // 70% of eval fees → pool LPs
    uint256 public constant PROTO_FEE_SHARE= 3000; // 30% → protocol treasury

    // ── Tier config ────────────────────────────────────────────────────────
    struct TierConfig {
        uint256 minSize;
        uint256 maxSize;
        uint256 feeBps;
        uint256 p1TargetBps;
        uint256 p2TargetBps;   // 0 = single-phase or instant
        uint256 dailyDDBps;
        uint256 totalDDBps;
        uint256 p1Days;
        uint256 p2Days;
        uint256 maxLeverage;
        uint256 initialSplitBps;
        bool    requiresEval;
    }
    mapping(uint8 => TierConfig) public tiers;

    // ── Eval account ───────────────────────────────────────────────────────
    enum EvalStatus { Active, Passed, Failed }
    enum EvalPhase  { Phase1, Phase2 }

    struct EvalAccount {
        address    trader;
        uint8      tier;
        EvalPhase  phase;
        EvalStatus status;
        uint256    accountSize;
        uint256    balance;          // current sim balance
        uint256    startBalance;     // reference for target calc
        uint256    peakBalance;
        uint256    dailyStartBalance;
        uint256    lastDayTs;
        uint256    p1StartTs;
        uint256    p2StartTs;
        uint256    feePaid;
        int256     realizedPnl;
        uint256    openTradeCount;
        uint256    totalTrades;
        bool       breached;
        string     breachReason;
        uint256    createdAt;
    }

    // ── Simulated trade ────────────────────────────────────────────────────
    struct SimTrade {
        uint256 evalId;
        address trader;
        uint256 marketIndex;
        bool    isLong;
        uint256 size;        // notional in USDC (6 dec)
        uint256 leverage;
        uint256 entryPrice;  // oracle price at open (8 dec)
        uint256 exitPrice;
        int256  pnl;         // USDC (6 dec) — set on close
        uint256 openTs;
        uint256 closeTs;
        bool    open;
    }

    mapping(uint256 => EvalAccount) public evals;
    mapping(uint256 => SimTrade)    public simTrades;
    mapping(address => uint256[])   public traderEvals;
    mapping(address => uint256)     public activeEvalId;
    mapping(uint256 => uint256[])   public evalTradeIds;

    uint256 public totalEvals;
    uint256 public totalSimTrades;
    uint256 public totalEvalsPassed;
    uint256 public totalEvalsFailed;
    uint256 public totalFeesCollected;

    // Events
    event EvalStarted(uint256 indexed id, address indexed trader, uint8 tier, uint256 size, uint256 fee);
    event SimTradeOpened(uint256 indexed tradeId, uint256 indexed evalId, uint256 market, bool isLong, uint256 size, uint256 entryPrice);
    event SimTradeClosed(uint256 indexed tradeId, uint256 indexed evalId, int256 pnl, uint256 exitPrice);
    event Phase2Unlocked(uint256 indexed evalId, address indexed trader);
    event EvalPassed(uint256 indexed evalId, address indexed trader, uint8 tier, uint256 fundedId);
    event EvalFailed(uint256 indexed evalId, address indexed trader, string reason);
    event BalanceUpdated(uint256 indexed evalId, uint256 newBalance, int256 pnl);

    constructor(address usdc, address _oracle, address owner) Ownable(owner) {
        USDC   = IERC20(usdc);
        oracle = _oracle;
        _initTiers();
    }

    function _initTiers() internal {
        tiers[1] = TierConfig(10_000*1e6, 200_000*1e6, 50,  800, 0,   400, 800,  30, 0,  100, 7000, true);
        tiers[2] = TierConfig(10_000*1e6, 200_000*1e6, 40,  800, 500, 500, 1000, 30, 60, 100, 8000, true);
        tiers[3] = TierConfig(5_000*1e6,  50_000*1e6,  300, 0,   0,   300, 600,  0,  0,  50,  6000, false);
    }

    // ── Start evaluation ───────────────────────────────────────────────────
    function startEval(uint8 tier, uint256 accountSize)
        external nonReentrant whenNotPaused
        returns (uint256 evalId)
    {
        TierConfig storage cfg = tiers[tier];
        require(cfg.minSize > 0,               "Eval: invalid tier");
        require(accountSize >= cfg.minSize,    "Eval: below minimum");
        require(accountSize <= cfg.maxSize,    "Eval: above maximum");
        require(activeEvalId[msg.sender] == 0, "Eval: already in evaluation");

        // Collect eval fee — only real USDC that changes hands
        uint256 fee = accountSize * cfg.feeBps / BPS;
        USDC.safeTransferFrom(msg.sender, address(this), fee);
        _distributeFee(fee);
        totalFeesCollected += fee;

        evalId = ++totalEvals;
        uint256 ts = block.timestamp;

        evals[evalId] = EvalAccount({
            trader: msg.sender, tier: tier,
            phase: EvalPhase.Phase1, status: EvalStatus.Active,
            accountSize: accountSize, balance: accountSize,
            startBalance: accountSize, peakBalance: accountSize,
            dailyStartBalance: accountSize, lastDayTs: ts,
            p1StartTs: ts, p2StartTs: 0,
            feePaid: fee, realizedPnl: 0,
            openTradeCount: 0, totalTrades: 0,
            breached: false, breachReason: "", createdAt: ts
        });

        traderEvals[msg.sender].push(evalId);
        activeEvalId[msg.sender] = evalId;

        emit EvalStarted(evalId, msg.sender, tier, accountSize, fee);

        // Tier 3 instant — no eval needed, jump straight to funded
        if (!cfg.requiresEval) {
            evals[evalId].status = EvalStatus.Passed;
            activeEvalId[msg.sender] = 0;
            totalEvalsPassed++;
            uint256 fundedId = IWikiPropFunded(fundedContract).createFundedAccount(
                msg.sender, accountSize, tier, cfg.initialSplitBps
            );
            emit EvalPassed(evalId, msg.sender, tier, fundedId);
        }
    }

    // ── Open simulated trade ───────────────────────────────────────────────
    /// @notice Paper trade — snapshots oracle price, no real position opened
    function openSimTrade(
        uint256 evalId,
        uint256 marketIndex,
        bool    isLong,
        uint256 size,
        uint256 leverage
    ) external nonReentrant whenNotPaused returns (uint256 tradeId) {
        EvalAccount storage e = evals[evalId];
        require(e.trader == msg.sender,        "Eval: not your eval");
        require(e.status == EvalStatus.Active, "Eval: not active");

        TierConfig storage cfg = tiers[e.tier];
        require(leverage >= 1 && leverage <= cfg.maxLeverage, "Eval: leverage out of range");

        // Margin check: required margin = notional / leverage
        uint256 margin = size / leverage;
        require(margin <= e.balance,           "Eval: insufficient sim balance");
        require(size <= e.accountSize / 2,     "Eval: max 50% account per trade");
        require(size > 0,                      "Eval: zero size");

        // Snapshot current oracle price — this is the ONLY real chain interaction
        (uint256 entryPrice, uint256 priceTs) = IWikiOracle(oracle).getPrice(marketIndex);
        require(entryPrice > 0,                "Eval: no oracle price");
        require(block.timestamp - priceTs < 5 minutes, "Eval: price stale");

        tradeId = ++totalSimTrades;
        simTrades[tradeId] = SimTrade({
            evalId:      evalId,
            trader:      msg.sender,
            marketIndex: marketIndex,
            isLong:      isLong,
            size:        size,
            leverage:    leverage,
            entryPrice:  entryPrice,
            exitPrice:   0,
            pnl:         0,
            openTs:      block.timestamp,
            closeTs:     0,
            open:        true
        });

        evalTradeIds[evalId].push(tradeId);
        e.openTradeCount++;
        e.totalTrades++;

        emit SimTradeOpened(tradeId, evalId, marketIndex, isLong, size, entryPrice);
    }

    // ── Close simulated trade ──────────────────────────────────────────────
    /// @notice Calculates P&L from oracle price delta, updates eval balance
    function closeSimTrade(uint256 tradeId)
        external nonReentrant
        returns (int256 pnl)
    {
        SimTrade storage t = simTrades[tradeId];
        require(t.trader == msg.sender, "Eval: not your trade");
        require(t.open,                 "Eval: already closed");

        EvalAccount storage e = evals[t.evalId];
        require(e.status == EvalStatus.Active, "Eval: not active");

        // Snapshot exit price — again, only oracle read, zero capital
        (uint256 exitPrice, uint256 priceTs) = IWikiOracle(oracle).getPrice(t.marketIndex);
        require(exitPrice > 0,              "Eval: no oracle price");
        require(block.timestamp - priceTs < 5 minutes, "Eval: price stale");

        // P&L calculation (USDC 6 dec, prices 8 dec → divide by 1e8 in price ratio)
        // net = size × |Δprice| / entryPrice
        if (t.isLong) {
            pnl = exitPrice >= t.entryPrice
                ? int256(t.size * (exitPrice - t.entryPrice) / t.entryPrice)
                : -int256(t.size * (t.entryPrice - exitPrice) / t.entryPrice);
        } else {
            pnl = t.entryPrice >= exitPrice
                ? int256(t.size * (t.entryPrice - exitPrice) / t.entryPrice)
                : -int256(t.size * (exitPrice - t.entryPrice) / t.entryPrice);
        }

        // Update sim trade
        t.open      = false;
        t.exitPrice = exitPrice;
        t.pnl       = pnl;
        t.closeTs   = block.timestamp;

        // Update eval account
        e.openTradeCount--;
        e.realizedPnl += pnl;
        _refreshDaily(e);

        if (pnl >= 0) {
            e.balance += uint256(pnl);
            if (e.balance > e.peakBalance) e.peakBalance = e.balance;
        } else {
            uint256 loss = uint256(-pnl);
            e.balance = e.balance > loss ? e.balance - loss : 0;
        }

        emit SimTradeClosed(tradeId, t.evalId, pnl, exitPrice);
        emit BalanceUpdated(t.evalId, e.balance, pnl);

        // Evaluate breach then pass
        if (!_checkBreach(t.evalId)) {
            _checkPass(t.evalId);
        }
    }

    // ── Real-time unrealized P&L view ──────────────────────────────────────
    function getUnrealizedPnl(uint256 tradeId) external view returns (int256) {
        SimTrade storage t = simTrades[tradeId];
        if (!t.open) return t.pnl;
        (uint256 cur,) = IWikiOracle(oracle).getPrice(t.marketIndex);
        if (cur == 0) return 0;
        if (t.isLong) {
            return cur >= t.entryPrice
                ? int256(t.size * (cur - t.entryPrice) / t.entryPrice)
                : -int256(t.size * (t.entryPrice - cur) / t.entryPrice);
        } else {
            return t.entryPrice >= cur
                ? int256(t.size * (t.entryPrice - cur) / t.entryPrice)
                : -int256(t.size * (cur - t.entryPrice) / t.entryPrice);
        }
    }

    /// @notice Effective balance = closed P&L + all open unrealized P&L
    function getEffectiveBalance(uint256 evalId) external view returns (uint256) {
        EvalAccount storage e = evals[evalId];
        int256 unrealized;
        uint256[] storage trades = evalTradeIds[evalId];
        for (uint i = 0; i < trades.length; i++) {
            SimTrade storage t = simTrades[trades[i]];
            if (!t.open) continue;
            (uint256 cur,) = IWikiOracle(oracle).getPrice(t.marketIndex);
            if (cur == 0) continue;
            if (t.isLong) {
                unrealized += cur >= t.entryPrice
                    ? int256(t.size * (cur - t.entryPrice) / t.entryPrice)
                    : -int256(t.size * (t.entryPrice - cur) / t.entryPrice);
            } else {
                unrealized += t.entryPrice >= cur
                    ? int256(t.size * (t.entryPrice - cur) / t.entryPrice)
                    : -int256(t.size * (cur - t.entryPrice) / t.entryPrice);
            }
        }
        int256 effective = int256(e.balance) + unrealized;
        return effective > 0 ? uint256(effective) : 0;
    }

    // ── Internal ───────────────────────────────────────────────────────────
    function _checkBreach(uint256 evalId) internal returns (bool) {
        EvalAccount storage e   = evals[evalId];
        TierConfig  storage cfg = tiers[e.tier];

        uint256 dLoss = e.dailyStartBalance > e.balance ? e.dailyStartBalance - e.balance : 0;
        if (dLoss >= e.accountSize * cfg.dailyDDBps / BPS) {
            _failEval(evalId, "Daily drawdown exceeded"); return true;
        }
        uint256 tLoss = e.peakBalance > e.balance ? e.peakBalance - e.balance : 0;
        if (tLoss >= e.accountSize * cfg.totalDDBps / BPS) {
            _failEval(evalId, "Total drawdown exceeded"); return true;
        }
        if (cfg.p1Days > 0 && e.phase == EvalPhase.Phase1
            && block.timestamp > e.p1StartTs + cfg.p1Days * 1 days) {
            _failEval(evalId, "Phase 1 time limit exceeded"); return true;
        }
        if (cfg.p2Days > 0 && e.phase == EvalPhase.Phase2
            && block.timestamp > e.p2StartTs + cfg.p2Days * 1 days) {
            _failEval(evalId, "Phase 2 time limit exceeded"); return true;
        }
        return false;
    }

    function _checkPass(uint256 evalId) internal {
        EvalAccount storage e   = evals[evalId];
        TierConfig  storage cfg = tiers[e.tier];
        if (e.phase == EvalPhase.Phase1) {
            if (e.balance >= e.startBalance + e.startBalance * cfg.p1TargetBps / BPS) {
                if (cfg.p2TargetBps == 0) {
                    _passEval(evalId);
                } else {
                    e.phase = EvalPhase.Phase2;
                    e.p2StartTs = block.timestamp;
                    e.startBalance = e.balance;
                    e.peakBalance  = e.balance;
                    e.dailyStartBalance = e.balance;
                    e.lastDayTs = block.timestamp;
                    emit Phase2Unlocked(evalId, e.trader);
                }
            }
        } else {
            if (e.balance >= e.startBalance + e.startBalance * cfg.p2TargetBps / BPS)
                _passEval(evalId);
        }
    }

    function _passEval(uint256 evalId) internal {
        EvalAccount storage e   = evals[evalId];
        TierConfig  storage cfg = tiers[e.tier];
        require(e.openTradeCount == 0, "Eval: close all sim trades first");
        e.status = EvalStatus.Passed;
        activeEvalId[e.trader] = 0;
        totalEvalsPassed++;
        // Hand off to funded contract — real money starts here
        uint256 fundedId = IWikiPropFunded(fundedContract).createFundedAccount(
            e.trader, e.accountSize, e.tier, cfg.initialSplitBps
        );
        emit EvalPassed(evalId, e.trader, e.tier, fundedId);
    }

    function _failEval(uint256 evalId, string memory reason) internal {
        EvalAccount storage e = evals[evalId];
        e.status = EvalStatus.Failed;
        e.breached = true;
        e.breachReason = reason;
        activeEvalId[e.trader] = 0;
        totalEvalsFailed++;
        emit EvalFailed(evalId, e.trader, reason);
    }

    function _refreshDaily(EvalAccount storage e) internal {
        if (block.timestamp >= e.lastDayTs + 1 days) {
            e.dailyStartBalance = e.balance;
            e.lastDayTs = block.timestamp;
        }
    }

    function _distributeFee(uint256 fee) internal {
        uint256 toPool  = fee * POOL_FEE_SHARE  / BPS;
        uint256 toProto = fee * PROTO_FEE_SHARE / BPS;
        if (propPool != address(0) && toPool > 0) {
            USDC.approve(propPool, toPool);
            IWikiPropPool(propPool).receiveEvalFee(toPool);
        }
        if (feeRecipient != address(0) && toProto > 0)
            USDC.safeTransfer(feeRecipient, toProto);
    }

    // ── Anyone can call to expire timed-out evals ──────────────────────────
    function checkExpiry(uint256 evalId) external {
        EvalAccount storage e   = evals[evalId];
        if (e.status != EvalStatus.Active) return;
        TierConfig  storage cfg = tiers[e.tier];
        if (e.phase == EvalPhase.Phase1 && cfg.p1Days > 0
            && block.timestamp > e.p1StartTs + cfg.p1Days * 1 days)
            _failEval(evalId, "Time limit exceeded");
        else if (e.phase == EvalPhase.Phase2 && cfg.p2Days > 0
            && block.timestamp > e.p2StartTs + cfg.p2Days * 1 days)
            _failEval(evalId, "Time limit exceeded");
    }

    // ── Views ──────────────────────────────────────────────────────────────
    function getEval(uint256 id)      external view returns (EvalAccount memory) { return evals[id]; }
    function getSimTrade(uint256 id)  external view returns (SimTrade memory)    { return simTrades[id]; }
    function getTraderEvals(address t) external view returns (uint256[] memory)  { return traderEvals[t]; }
    function getEvalTrades(uint256 id) external view returns (uint256[] memory)  { return evalTradeIds[id]; }
    function evalFee(uint8 tier, uint256 size) external view returns (uint256)   { return size * tiers[tier].feeBps / BPS; }

    function evalProgress(uint256 evalId) external view returns (
        uint256 profitPct, uint256 targetPct, uint256 dailyDDUsed,
        uint256 totalDDUsed, uint256 daysRemaining, bool onTrack
    ) {
        EvalAccount storage e   = evals[evalId];
        TierConfig  storage cfg = tiers[e.tier];
        profitPct    = e.balance > e.startBalance ? (e.balance - e.startBalance) * BPS / e.startBalance : 0;
        targetPct    = e.phase == EvalPhase.Phase1 ? cfg.p1TargetBps : cfg.p2TargetBps;
        uint256 dL   = e.dailyStartBalance > e.balance ? e.dailyStartBalance - e.balance : 0;
        dailyDDUsed  = dL * BPS / e.accountSize;
        uint256 tL   = e.peakBalance > e.balance ? e.peakBalance - e.balance : 0;
        totalDDUsed  = tL * BPS / e.accountSize;
        uint256 end  = e.phase == EvalPhase.Phase1
            ? e.p1StartTs + cfg.p1Days * 1 days
            : e.p2StartTs + cfg.p2Days * 1 days;
        daysRemaining = end > block.timestamp ? (end - block.timestamp) / 1 days : 0;
        onTrack = !e.breached && dailyDDUsed < cfg.dailyDDBps / 2 && profitPct > 0;
    }

    // ── Admin ──────────────────────────────────────────────────────────────
    function setOracle(address o)         external onlyOwner { oracle         = o; }
    function setFundedContract(address f) external onlyOwner { fundedContract = f; }
    function setPropPool(address p)       external onlyOwner { propPool       = p; }
    function setFeeRecipient(address f)   external onlyOwner { feeRecipient   = f; }
    function updateTier(uint8 t, TierConfig calldata cfg) external onlyOwner { tiers[t] = cfg; }
    function pause()   external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }
}
