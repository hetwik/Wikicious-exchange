// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@chainlink/contracts/src/v0.8/shared/interfaces/AggregatorV3Interface.sol";
import "@openzeppelin/contracts/access/Ownable2Step.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

/// @title WikiOracle — Hardened multi-source price oracle
///
/// ATTACK MITIGATIONS:
/// [A1] Flash loan oracle manipulation → TWAP check blocks single-block price spikes
/// [A2] Stale Chainlink data → heartbeat staleness check, reject if expired
/// [A3] Chainlink circuit breaker → min/max price bounds, reject out-of-range answers
/// [A4] Incomplete Chainlink round → answeredInRound >= roundId check
/// [A5] Arbitrum sequencer downtime → L2 sequencer uptime feed + grace period
/// [A6] Guardian manipulation → deviation check vs TWAP, TTL expiry
/// [A7] Accidental owner transfer → Ownable2Step requires explicit acceptance
/// [A8] Source disagreement attack → cross-validate Chainlink vs guardian, revert if mismatch

// Arbitrum L2 sequencer uptime feed: 0xFdB631F5EE196F0ed6FAa767959853A9F217697D
interface ISequencerUptimeFeed {
    function latestRoundData() external view returns (
        uint80, int256 answer, uint256 startedAt, uint256, uint80
    );
}

contract WikiOracle is Ownable2Step, Pausable {

    struct Feed {
        AggregatorV3Interface chainlink;
        uint32  heartbeat;
        uint8   decimals;
        uint256 minPrice;   // 18 dec hard floor
        uint256 maxPrice;   // 18 dec hard ceiling
        bool    active;
    }

    struct GuardianPrice {
        uint256 price;
        uint256 submittedAt;
    }

    struct TWAPEntry {
        uint256 price;
        uint256 ts;
    }

    mapping(bytes32 => Feed)            public  feeds;
    mapping(bytes32 => GuardianPrice)   public  guardianPrices;
    mapping(bytes32 => TWAPEntry[10])   private _twap;
    mapping(bytes32 => uint8)           private _twapIdx;
    mapping(bytes32 => uint8)           private _twapLen;
    mapping(address  => bool)           public  guardians;
    mapping(bytes32  => bool)           public  marketPaused;

    ISequencerUptimeFeed public immutable sequencerFeed;

    uint256 public constant GUARDIAN_TTL        = 3600;   // 1 hour
    uint256 public constant MAX_DEVIATION_BPS   = 500;    // 5%
    uint256 public constant TWAP_WINDOW         = 300;    // 5 min
    uint256 public constant SEQ_GRACE_PERIOD    = 3600;   // 1h after sequencer restart
    uint256 public constant BPS                 = 10000;

    event FeedConfigured(bytes32 indexed id, address cl, uint256 minP, uint256 maxP);
    event GuardianPriceSet(bytes32 indexed id, uint256 price, address by);
    event GuardianUpdated(address indexed g, bool active);
    event MarketPaused(bytes32 indexed id, bool paused);

    constructor(address owner, address _seqFeed) Ownable(owner) {
        sequencerFeed = ISequencerUptimeFeed(_seqFeed);
        guardians[owner] = true;
    }

    modifier onlyGuardian() { require(guardians[msg.sender], "Oracle: not guardian"); _; }

    // ── Admin ──────────────────────────────────────────────────────────────
    function setFeed(
        bytes32 id, address cl, uint32 heartbeat, uint8 decimals,
        uint256 minPrice, uint256 maxPrice
    ) external onlyOwner {
        require(minPrice > 0 && minPrice < maxPrice, "Oracle: bad bounds");
        require(heartbeat > 0 && heartbeat <= 86400,  "Oracle: bad heartbeat");
        feeds[id] = Feed(AggregatorV3Interface(cl), heartbeat, decimals, minPrice, maxPrice, true);
        emit FeedConfigured(id, cl, minPrice, maxPrice);
    }

    function setGuardian(address g, bool active) external onlyOwner {
        guardians[g] = active;
        emit GuardianUpdated(g, active);
    }

    function pauseMarket(bytes32 id, bool p) external onlyOwner {
        marketPaused[id] = p;
        emit MarketPaused(id, p);
    }

    function pause()   external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    // ── Guardian price ──────────────────────────────────────────────────────
    function submitGuardianPrice(bytes32 id, uint256 price) external onlyGuardian whenNotPaused {
        Feed storage f = feeds[id];
        require(f.active,           "Oracle: inactive market");
        require(price >= f.minPrice,"Oracle: below floor");
        require(price <= f.maxPrice,"Oracle: above ceiling");

        // [A6] Must not deviate >5% from TWAP
        uint256 twap = _getTWAP(id);
        if (twap > 0) _assertDeviation(price, twap);

        guardianPrices[id] = GuardianPrice(price, block.timestamp);
        emit GuardianPriceSet(id, price, msg.sender);
    }

    // ── Primary getter — state-mutating (updates TWAP) ─────────────────────
    function getPrice(bytes32 id)
        external whenNotPaused
        returns (uint256 price, uint256 ts)
    {
        require(!marketPaused[id], "Oracle: market paused");
        _checkSequencer(); // [A5]

        Feed storage f = feeds[id];
        require(f.active, "Oracle: market not found");

        (price, ts) = _validated(f, id);
        _pushTWAP(id, price);   // [A1] update rolling TWAP
    }

    // ── Read-only getter (no TWAP update) ──────────────────────────────────
    function getPriceSafe(bytes32 id) external view returns (uint256 price, bool valid) {
        if (marketPaused[id] || !feeds[id].active) return (0, false);
        try this.getPriceView(id) returns (uint256 p, uint256) {
            return (p, p > 0);
        } catch {
            return (0, false);
        }
    }

    function getPriceView(bytes32 id) external view returns (uint256 price, uint256 ts) {
        return _validated(feeds[id], id);
    }

    function getTWAP(bytes32 id) external view returns (uint256) {
        return _getTWAP(id);
    }

    // ── Internal ───────────────────────────────────────────────────────────
    function _validated(Feed storage f, bytes32 id)
        internal view returns (uint256 price, uint256 ts)
    {
        bool   clOk;
        uint256 clPrice;
        uint256 clTs;

        // ── [A2][A3][A4] Chainlink validation ────────────────────────────
        if (address(f.chainlink) != address(0)) {
            try f.chainlink.latestRoundData() returns (
                uint80 rId, int256 ans, uint256, uint256 updAt, uint80 answRId
            ) {
                if (
                    ans > 0                                         // [A3] positive
                    && updAt > 0                                    // [A2] non-zero
                    && answRId >= rId                               // [A4] round complete
                    && block.timestamp - updAt <= f.heartbeat       // [A2] not stale
                ) {
                    uint256 p = _norm(uint256(ans), f.decimals);
                    if (p >= f.minPrice && p <= f.maxPrice) {       // [A3] within bounds
                        clPrice = p; clTs = updAt; clOk = true;
                    }
                }
            } catch {}
        }

        // ── Guardian fallback ─────────────────────────────────────────────
        GuardianPrice storage gp = guardianPrices[id];
        bool gpOk = gp.price > 0
            && block.timestamp - gp.submittedAt <= GUARDIAN_TTL
            && gp.price >= f.minPrice
            && gp.price <= f.maxPrice;

        require(clOk || gpOk, "Oracle: no valid price");

        if (clOk && gpOk) {
            // [A8] Cross-validate — if sources disagree >5%, something is wrong
            _assertDeviation(clPrice, gp.price);
            price = clPrice; ts = clTs;          // Chainlink wins
        } else if (clOk) {
            price = clPrice; ts = clTs;
        } else {
            price = gp.price; ts = gp.submittedAt;
        }

        // [A1] Final TWAP check — protects against flash loan manipulation
        uint256 twap = _getTWAP(id);
        if (twap > 0) _assertDeviation(price, twap);
    }

    // ── [A5] Arbitrum sequencer check ─────────────────────────────────────
    function _checkSequencer() internal view {
        (, int256 ans, uint256 startedAt,,) = sequencerFeed.latestRoundData();
        require(ans == 0, "Oracle: L2 sequencer offline");
        require(block.timestamp - startedAt > SEQ_GRACE_PERIOD, "Oracle: sequencer grace period active");
    }

    // ── TWAP ring buffer ──────────────────────────────────────────────────
    function _pushTWAP(bytes32 id, uint256 price) internal {
        uint8 idx = _twapIdx[id];
        _twap[id][idx] = TWAPEntry(price, block.timestamp);
        _twapIdx[id]   = uint8((idx + 1) % 10);
        if (_twapLen[id] < 10) _twapLen[id]++;
    }

    function _getTWAP(bytes32 id) internal view returns (uint256) {
        uint8 len = _twapLen[id];
        if (len == 0) return 0;
        uint256 cutoff = block.timestamp > TWAP_WINDOW ? block.timestamp - TWAP_WINDOW : 0;
        uint256 sum; uint256 cnt;
        for (uint8 i = 0; i < len; i++) {
            TWAPEntry storage e = _twap[id][i];
            if (e.ts >= cutoff) { sum += e.price; cnt++; }
        }
        if (cnt == 0) {
            // All entries older than window — use most recent
            sum = _twap[id][(_twapIdx[id] + 10 - 1) % 10].price;
            cnt = 1;
        }
        return sum / cnt;
    }

    function _assertDeviation(uint256 a, uint256 b) internal pure {
        uint256 dev = a > b ? (a - b) * BPS / b : (b - a) * BPS / a;
        require(dev <= MAX_DEVIATION_BPS, "Oracle: price deviation exceeded");
    }

    function _norm(uint256 price, uint8 dec) internal pure returns (uint256) {
        if (dec == 18) return price;
        if (dec < 18)  return price * 10 ** (18 - dec);
        return price / 10 ** (dec - 18);
    }
}
