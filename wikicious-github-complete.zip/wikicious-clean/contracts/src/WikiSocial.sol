// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/access/Ownable2Step.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

/// @title WikiSocial — Decentralized social layer for Wikicious
///
/// INTEGRATION WITH EXCHANGE:
///   - Same wallet address = trading account + social profile + WIK holder
///   - Traders can share positions as posts (position ID stored on-chain)
///   - Profile shows verified badge if wallet has traded >$10k volume
///   - Likes/comments trigger WIK rewards via WikiSocialRewards contract
///
/// STORAGE MODEL:
///   Content (text/images/video) → Arweave (permanent) or IPFS (media)
///   Only 32-byte content hashes stored on-chain — gas efficient
///   Arweave TX IDs encoded as bytes32 (keccak of the TX ID string)
///   IPFS CIDs encoded as bytes32 (sha256 of content)
///
/// DECENTRALIZATION:
///   No company owns content — lives on Arweave/IPFS forever
///   No server to shut down — contract is immutable after deploy
///   No account bans — only spam limits enforced by contract rules

interface IWikiSocialRewards {
    function onPostCreated(uint256 postId, address author) external;
    function onLike(uint256 postId, address liker, address author) external;
    function onComment(uint256 postId, address commenter, address author) external;
    function onRepost(uint256 postId, address reposter, address author) external;
    function onFollow(address follower, address followed) external;
}

interface IWikiVault {
    function totalMargin(address user) external view returns (uint256);
}

interface IWikiPerp {
    function getPosition(uint256 posId) external view returns (
        address trader, uint256 marketIndex, bool isLong,
        uint256 size, uint256 collateral, uint256 entryPrice,
        uint256, uint256, uint256, uint256, uint256, uint256, bool open
    );
}

contract WikiSocial is Ownable2Step, ReentrancyGuard, Pausable {

    enum MediaType { None, Image, Video, Audio }
    enum PostType  { Original, Comment, Repost, Quote }

    struct Profile {
        address  wallet;
        string   handle;          // unique @handle
        string   displayName;
        bytes32  avatarArweave;   // Arweave TX ID hash for avatar image
        bytes32  bannerArweave;   // Arweave TX ID hash for banner image
        string   bio;             // max 160 chars
        string   website;
        uint256  followerCount;
        uint256  followingCount;
        uint256  postCount;
        uint256  totalLikesReceived;
        uint256  joinedAt;
        bool     verified;        // set by owner — blue tick
        bool     traderVerified;  // auto-set when wallet has >$10k exchange volume
        bool     active;
    }

    struct Post {
        uint256   id;
        address   author;
        PostType  postType;
        bytes32   contentArweave; // Arweave TX ID hash — full text+metadata JSON
        bytes32   mediaIPFS;      // IPFS CID — image/video bytes (0 if none)
        MediaType mediaType;
        uint256   parentId;       // for Comment/Quote: parent post ID
        uint256   likeCount;
        uint256   commentCount;
        uint256   repostCount;
        uint256   quoteCount;
        uint256   viewCount;      // updated by trusted oracle
        uint256   engagementScore;
        uint256   createdAt;
        bool      deleted;
        // Exchange integration — optional
        uint256   linkedPositionId; // 0 = not linked to a trade
        bool      isTradePost;      // true if this post shares a position
    }

    // ── Storage ────────────────────────────────────────────────────────────
    mapping(address => Profile)  public profiles;
    mapping(string  => address)  public handleToAddress;
    mapping(uint256 => Post)     public posts;
    mapping(uint256 => mapping(address => bool)) public hasLiked;
    mapping(address => mapping(address => bool)) public isFollowing;
    mapping(string  => uint256[]) public hashtagPosts;
    mapping(string  => uint256)   public hashtagPostCount;
    mapping(address => uint256[]) public userPostIds;
    mapping(address => uint256[]) public userLikedPostIds;

    // Anti-spam: posts per day per user
    mapping(address => uint256) private _lastPostDay;
    mapping(address => uint256) private _postsToday;

    uint256 public totalPosts;
    uint256 public totalProfiles;

    // Integration contracts
    address public rewardsContract;
    address public vaultContract;
    address public perpContract;
    mapping(address => bool) public trustedOracles; // can update view counts

    // Limits
    uint256 public constant MAX_BIO        = 160;
    uint256 public constant MAX_HANDLE     = 30;
    uint256 public constant MIN_HANDLE     = 3;
    uint256 public constant MAX_TAGS       = 5;
    uint256 public constant MAX_POSTS_DAY  = 100;
    uint256 public constant TRADER_VERIFY_THRESHOLD = 10_000 * 1e6; // $10k USDC

    // ── Events ─────────────────────────────────────────────────────────────
    event ProfileCreated(address indexed wallet, string handle, uint256 ts);
    event ProfileUpdated(address indexed wallet);
    event HandleChanged(address indexed wallet, string oldHandle, string newHandle);
    event PostCreated(uint256 indexed postId, address indexed author, PostType t, bytes32 contentHash);
    event TradePostCreated(uint256 indexed postId, address indexed author, uint256 positionId);
    event PostDeleted(uint256 indexed postId, address indexed author);
    event Liked(uint256 indexed postId, address indexed liker, address indexed author);
    event Unliked(uint256 indexed postId, address indexed liker);
    event CommentPosted(uint256 indexed commentId, uint256 indexed parentId, address indexed author);
    event Reposted(uint256 indexed newId, uint256 indexed origId, address indexed reposter);
    event Quoted(uint256 indexed newId, uint256 indexed origId, address indexed quoter);
    event Followed(address indexed follower, address indexed followed);
    event Unfollowed(address indexed follower, address indexed followed);
    event TraderVerified(address indexed wallet);
    event HashtagIndexed(string indexed tag, uint256 indexed postId);

    constructor(address owner) Ownable(owner) {}

    // ── Profile ────────────────────────────────────────────────────────────
    function register(
        string calldata handle,
        string calldata displayName,
        string calldata bio,
        string calldata website
    ) external nonReentrant whenNotPaused {
        require(!profiles[msg.sender].active,          "Social: already registered");
        require(handleToAddress[handle] == address(0), "Social: handle taken");
        require(_validHandle(handle),                  "Social: invalid handle");
        require(bytes(bio).length <= MAX_BIO,          "Social: bio too long");

        profiles[msg.sender] = Profile({
            wallet: msg.sender, handle: handle, displayName: displayName,
            avatarArweave: bytes32(0), bannerArweave: bytes32(0),
            bio: bio, website: website,
            followerCount: 0, followingCount: 0, postCount: 0,
            totalLikesReceived: 0, joinedAt: block.timestamp,
            verified: false,
            // Auto-grant trader verified if wallet already has exchange deposits
            traderVerified: _isActiveTrader(msg.sender),
            active: true
        });
        handleToAddress[handle] = msg.sender;
        totalProfiles++;
        emit ProfileCreated(msg.sender, handle, block.timestamp);
    }

    function updateProfile(
        string  calldata displayName,
        string  calldata bio,
        string  calldata website,
        bytes32          avatarArweave,
        bytes32          bannerArweave
    ) external nonReentrant whenNotPaused {
        require(profiles[msg.sender].active, "Social: no profile");
        require(bytes(bio).length <= MAX_BIO, "Social: bio too long");
        Profile storage p = profiles[msg.sender];
        p.displayName = displayName;
        p.bio         = bio;
        p.website     = website;
        if (avatarArweave != bytes32(0)) p.avatarArweave = avatarArweave;
        if (bannerArweave  != bytes32(0)) p.bannerArweave  = bannerArweave;
        // Re-check trader status on every profile update
        if (!p.traderVerified && _isActiveTrader(msg.sender)) {
            p.traderVerified = true;
            emit TraderVerified(msg.sender);
        }
        emit ProfileUpdated(msg.sender);
    }

    function changeHandle(string calldata newHandle) external nonReentrant whenNotPaused {
        require(profiles[msg.sender].active,              "Social: no profile");
        require(handleToAddress[newHandle] == address(0), "Social: handle taken");
        require(_validHandle(newHandle),                  "Social: invalid handle");
        string memory old = profiles[msg.sender].handle;
        delete handleToAddress[old];
        handleToAddress[newHandle] = msg.sender;
        profiles[msg.sender].handle = newHandle;
        emit HandleChanged(msg.sender, old, newHandle);
    }

    // ── Posts ──────────────────────────────────────────────────────────────
    /// @notice Create original post. Content stored on Arweave, hash here.
    /// @param contentArweave  keccak256 of Arweave TX ID — full text/metadata JSON
    /// @param mediaIPFS       sha256 of IPFS CID — for image/video (0 = text only)
    /// @param mediaType       MediaType enum
    /// @param tags            Hashtags without # (max 5)
    function createPost(
        bytes32           contentArweave,
        bytes32           mediaIPFS,
        MediaType         mediaType,
        string[] calldata tags
    ) external nonReentrant whenNotPaused returns (uint256 postId) {
        _requireProfile();
        require(contentArweave != bytes32(0), "Social: no content hash");
        require(tags.length <= MAX_TAGS,      "Social: too many tags");
        _checkSpam();
        postId = _newPost(msg.sender, PostType.Original, contentArweave, mediaIPFS, mediaType, 0, 0, false);
        _indexTags(postId, tags);
        _notifyRewards_post(postId);
    }

    /// @notice Share a trade — links post to an on-chain position
    /// @param positionId  WikiPerp position ID being shared
    /// @param commentary  Arweave hash for the commentary text
    function shareTradePost(
        uint256   positionId,
        bytes32   commentary,
        bytes32   mediaIPFS,
        MediaType mediaType
    ) external nonReentrant whenNotPaused returns (uint256 postId) {
        _requireProfile();
        require(commentary != bytes32(0), "Social: no content");
        _checkSpam();

        // Verify position belongs to caller if perp contract set
        if (perpContract != address(0)) {
            (address trader,,,,,,,,,,,, bool open) = IWikiPerp(perpContract).getPosition(positionId);
            require(trader == msg.sender, "Social: not your position");
            // Can share open or recently closed positions
        }

        postId = _newPost(msg.sender, PostType.Original, commentary, mediaIPFS, mediaType, 0, positionId, true);
        emit TradePostCreated(postId, msg.sender, positionId);
        _notifyRewards_post(postId);
    }

    /// @notice Comment on a post
    function comment(
        uint256   parentId,
        bytes32   contentArweave,
        bytes32   mediaIPFS,
        MediaType mediaType
    ) external nonReentrant whenNotPaused returns (uint256 commentId) {
        _requireProfile();
        require(parentId < totalPosts,        "Social: invalid parent");
        require(!posts[parentId].deleted,     "Social: parent deleted");
        require(contentArweave != bytes32(0), "Social: no content");
        _checkSpam();

        commentId = _newPost(msg.sender, PostType.Comment, contentArweave, mediaIPFS, mediaType, parentId, 0, false);
        posts[parentId].commentCount++;
        _updateEngagement(parentId, 5); // 5 pts per comment
        emit CommentPosted(commentId, parentId, msg.sender);
        _notifyRewards_comment(parentId);
    }

    /// @notice Repost (no added text)
    function repost(uint256 origId) external nonReentrant whenNotPaused returns (uint256 newId) {
        _requireProfile();
        require(origId < totalPosts,      "Social: invalid post");
        require(!posts[origId].deleted,   "Social: deleted");
        _checkSpam();

        Post storage orig = posts[origId];
        newId = _newPost(msg.sender, PostType.Repost, orig.contentArweave, orig.mediaIPFS, orig.mediaType, origId, 0, false);
        orig.repostCount++;
        _updateEngagement(origId, 3); // 3 pts per repost
        emit Reposted(newId, origId, msg.sender);
        if (rewardsContract != address(0))
            IWikiSocialRewards(rewardsContract).onRepost(origId, msg.sender, orig.author);
    }

    /// @notice Quote post with commentary
    function quotePost(
        uint256   origId,
        bytes32   contentArweave,
        bytes32   mediaIPFS,
        MediaType mediaType
    ) external nonReentrant whenNotPaused returns (uint256 newId) {
        _requireProfile();
        require(origId < totalPosts,          "Social: invalid post");
        require(!posts[origId].deleted,       "Social: deleted");
        require(contentArweave != bytes32(0), "Social: no content");
        _checkSpam();

        newId = _newPost(msg.sender, PostType.Quote, contentArweave, mediaIPFS, mediaType, origId, 0, false);
        posts[origId].quoteCount++;
        _updateEngagement(origId, 4);
        emit Quoted(newId, origId, msg.sender);
        _notifyRewards_post(newId);
    }

    /// @notice Delete your own post (flag only — Arweave content is permanent)
    function deletePost(uint256 postId) external nonReentrant {
        require(posts[postId].author == msg.sender || msg.sender == owner(), "Social: not authorized");
        require(!posts[postId].deleted, "Social: already deleted");
        posts[postId].deleted = true;
        if (profiles[msg.sender].postCount > 0) profiles[msg.sender].postCount--;
        emit PostDeleted(postId, msg.sender);
    }

    // ── Likes ──────────────────────────────────────────────────────────────
    function likePost(uint256 postId) external nonReentrant whenNotPaused {
        _requireProfile();
        require(postId < totalPosts,              "Social: invalid post");
        require(!posts[postId].deleted,           "Social: deleted");
        require(!hasLiked[postId][msg.sender],    "Social: already liked");

        hasLiked[postId][msg.sender] = true;
        posts[postId].likeCount++;
        _updateEngagement(postId, 10); // 10 pts per like — highest weight
        address author = posts[postId].author;
        profiles[author].totalLikesReceived++;
        userLikedPostIds[msg.sender].push(postId);

        emit Liked(postId, msg.sender, author);

        if (rewardsContract != address(0))
            IWikiSocialRewards(rewardsContract).onLike(postId, msg.sender, author);
    }

    function unlikePost(uint256 postId) external nonReentrant {
        require(hasLiked[postId][msg.sender], "Social: not liked");
        hasLiked[postId][msg.sender] = false;
        if (posts[postId].likeCount > 0) posts[postId].likeCount--;
        address author = posts[postId].author;
        if (profiles[author].totalLikesReceived > 0) profiles[author].totalLikesReceived--;
        emit Unliked(postId, msg.sender);
    }

    // ── Follow ─────────────────────────────────────────────────────────────
    function follow(address target) external nonReentrant whenNotPaused {
        _requireProfile();
        require(profiles[target].active,              "Social: target not registered");
        require(target != msg.sender,                 "Social: cannot follow self");
        require(!isFollowing[msg.sender][target],     "Social: already following");

        isFollowing[msg.sender][target] = true;
        profiles[msg.sender].followingCount++;
        profiles[target].followerCount++;
        emit Followed(msg.sender, target);

        if (rewardsContract != address(0))
            IWikiSocialRewards(rewardsContract).onFollow(msg.sender, target);
    }

    function unfollow(address target) external nonReentrant {
        require(isFollowing[msg.sender][target], "Social: not following");
        isFollowing[msg.sender][target] = false;
        if (profiles[msg.sender].followingCount > 0) profiles[msg.sender].followingCount--;
        if (profiles[target].followerCount > 0)      profiles[target].followerCount--;
        emit Unfollowed(msg.sender, target);
    }

    // ── Oracle: update view count ──────────────────────────────────────────
    function updateViewCount(uint256 postId, uint256 views) external {
        require(trustedOracles[msg.sender], "Social: not oracle");
        require(postId < totalPosts,        "Social: invalid post");
        posts[postId].viewCount = views;
        _updateEngagement(postId, 0); // recalculate
    }

    // ── Admin ──────────────────────────────────────────────────────────────
    function setRewardsContract(address r) external onlyOwner { rewardsContract = r; }
    function setVaultContract(address v)   external onlyOwner { vaultContract = v; }
    function setPerpContract(address p)    external onlyOwner { perpContract = p; }
    function setTrustedOracle(address o, bool t) external onlyOwner { trustedOracles[o] = t; }
    function verifyProfile(address w, bool v) external onlyOwner {
        profiles[w].verified = v;
        emit ProfileUpdated(w);
    }
    function pause()   external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    // ── Views ──────────────────────────────────────────────────────────────
    function getPost(uint256 id)       external view returns (Post    memory) { return posts[id]; }
    function getProfile(address w)     external view returns (Profile memory) { return profiles[w]; }
    function getProfileByHandle(string calldata h) external view returns (Profile memory) {
        return profiles[handleToAddress[h]];
    }
    function getUserPosts(address w)      external view returns (uint256[] memory) { return userPostIds[w]; }
    function getUserLikedPosts(address w) external view returns (uint256[] memory) { return userLikedPostIds[w]; }
    function getHashtagPosts(string calldata tag) external view returns (uint256[] memory) { return hashtagPosts[tag]; }

    /// @notice Get post IDs by multiple users (for feed construction)
    function getPostsByAuthors(address[] calldata authors, uint256 limit)
        external view returns (uint256[] memory result)
    {
        uint256[] memory tmp = new uint256[](limit);
        uint256 count = 0;
        for (uint i = 0; i < authors.length && count < limit; i++) {
            uint256[] storage up = userPostIds[authors[i]];
            for (uint j = up.length; j > 0 && count < limit; j--) {
                tmp[count++] = up[j-1];
            }
        }
        result = new uint256[](count);
        for (uint i = 0; i < count; i++) result[i] = tmp[i];
    }

    // ── Internal ───────────────────────────────────────────────────────────
    function _newPost(
        address   author,
        PostType  pt,
        bytes32   contentArweave,
        bytes32   mediaIPFS,
        MediaType mediaType,
        uint256   parentId,
        uint256   linkedPosId,
        bool      isTradePost
    ) internal returns (uint256 postId) {
        postId = totalPosts++;
        posts[postId] = Post({
            id: postId, author: author, postType: pt,
            contentArweave: contentArweave, mediaIPFS: mediaIPFS, mediaType: mediaType,
            parentId: parentId, likeCount: 0, commentCount: 0, repostCount: 0,
            quoteCount: 0, viewCount: 0, engagementScore: 0,
            createdAt: block.timestamp, deleted: false,
            linkedPositionId: linkedPosId, isTradePost: isTradePost
        });
        userPostIds[author].push(postId);
        profiles[author].postCount++;
        emit PostCreated(postId, author, pt, contentArweave);
    }

    function _updateEngagement(uint256 postId, uint256 addPts) internal {
        Post storage p = posts[postId];
        // Weighted score: likes×10 + comments×5 + reposts×3 + quotes×4 + views/100
        p.engagementScore = p.likeCount * 10
            + p.commentCount * 5
            + p.repostCount  * 3
            + p.quoteCount   * 4
            + p.viewCount    / 100
            + addPts;
    }

    function _indexTags(uint256 postId, string[] calldata tags) internal {
        for (uint i = 0; i < tags.length; i++) {
            string memory tag = tags[i];
            if (bytes(tag).length == 0 || bytes(tag).length > 50) continue;
            hashtagPosts[tag].push(postId);
            hashtagPostCount[tag]++;
            emit HashtagIndexed(tag, postId);
        }
    }

    function _checkSpam() internal {
        uint256 today = block.timestamp / 86400;
        if (_lastPostDay[msg.sender] < today) {
            _lastPostDay[msg.sender] = today;
            _postsToday[msg.sender]  = 0;
        }
        _postsToday[msg.sender]++;
        require(_postsToday[msg.sender] <= MAX_POSTS_DAY, "Social: daily post limit");
    }

    function _requireProfile() internal view {
        require(profiles[msg.sender].active, "Social: no profile — register first");
    }

    function _isActiveTrader(address w) internal view returns (bool) {
        if (vaultContract == address(0)) return false;
        try IWikiVault(vaultContract).totalMargin(w) returns (uint256 margin) {
            return margin >= TRADER_VERIFY_THRESHOLD;
        } catch { return false; }
    }

    function _validHandle(string calldata h) internal pure returns (bool) {
        bytes memory b = bytes(h);
        if (b.length < MIN_HANDLE || b.length > MAX_HANDLE) return false;
        for (uint i = 0; i < b.length; i++) {
            bytes1 c = b[i];
            bool ok = (c >= 0x61 && c <= 0x7A) // a-z
                   || (c >= 0x30 && c <= 0x39) // 0-9
                   || c == 0x5F;               // _
            if (!ok) return false;
        }
        return true;
    }

    function _notifyRewards_post(uint256 postId) internal {
        if (rewardsContract != address(0))
            IWikiSocialRewards(rewardsContract).onPostCreated(postId, msg.sender);
    }

    function _notifyRewards_comment(uint256 parentId) internal {
        if (rewardsContract != address(0))
            IWikiSocialRewards(rewardsContract).onComment(parentId, msg.sender, posts[parentId].author);
    }
}
