const { ethers } = require("hardhat");
const fs = require("fs");
const path = require("path");

// Arbitrum Mainnet Chainlink Price Feeds
const CHAINLINK_FEEDS = {
  BTCUSDT:  { feed: "0x6ce185539ad4fdaeBc62adeD98E2AE0C68b4cFf", heartbeat: 86400, dec: 8 },
  ETHUSDT:  { feed: "0x639Fe6ab55C921f74e7fac1ee960C0B6293ba612", heartbeat: 86400, dec: 8 },
  BNBUSDT:  { feed: "0x6970460aabF80C5BE983C6b74e5D06dEDCA95D4A", heartbeat: 86400, dec: 8 },
  SOLUSDT:  { feed: "0x24ceA4b8ce57cdA0CF197633052aaF383B2F5D00", heartbeat: 86400, dec: 8 },
  ADAUSDT:  { feed: "0xD9f615A9b820225edbA2d821c4A696a0924051c6", heartbeat: 86400, dec: 8 },
  XRPUSDT:  { feed: "0xB4AD57B52aB9141de9926a3e0C8dc6264c2ef205", heartbeat: 86400, dec: 8 },
  DOGEUSDT: { feed: "0x9A7FB1b3950837a8D9b40517626E11D4127C098C", heartbeat: 86400, dec: 8 },
  DOTUSDT:  { feed: "0xa28dCaB66FD25c668aCC7f232aa71DA1943E04b8", heartbeat: 86400, dec: 8 },
  AVAXUSDT: { feed: "0x8bf61728eeDCE2F32c456454d87B5d6eD6150208", heartbeat: 86400, dec: 8 },
  LINKUSDT: { feed: "0x86E53CF1B873786aC9Cc9b91963FE51A6Ce9EE2A", heartbeat: 86400, dec: 8 },
  UNIUSDT:  { feed: "0x9C917083fDb403ab5ADbEC26Ee294f6EcAda2720", heartbeat: 86400, dec: 8 },
  MATICUSDT:{ feed: "0x52099D4523531f678Dfc568a7B1e5038aadcE1d6", heartbeat: 86400, dec: 8 },
  ARBUSDT:  { feed: "0xb2A824043730FE05F3DA2efaFa1CBbe83fa548D6", heartbeat: 86400, dec: 8 },
  OPUSDT:   { feed: "0x205aaD468a11fd5D34fA7211bC6Bad5b3deB9b98", heartbeat: 86400, dec: 8 },
  GMXUSDT:  { feed: "0xDB98056FecFff59D032aB628337A4887110df3dB", heartbeat: 86400, dec: 8 },
};

// Markets with leverage limits
const MARKETS = [
  // Major pairs — highest leverage
  { symbol:"BTCUSDT",  maxLev:125, makerFee:2,  takerFee:4,  mmBps:40,  maxOI: "50000000000000" }, // 50M USDC each side
  { symbol:"ETHUSDT",  maxLev:100, makerFee:2,  takerFee:4,  mmBps:50,  maxOI: "40000000000000" },
  { symbol:"ARBUSDT",  maxLev:50,  makerFee:2,  takerFee:5,  mmBps:100, maxOI: "10000000000000" },
  { symbol:"OPUSDT",   maxLev:50,  makerFee:2,  takerFee:5,  mmBps:100, maxOI: "5000000000000"  },
  // Mid-caps
  { symbol:"BNBUSDT",  maxLev:75,  makerFee:2,  takerFee:5,  mmBps:75,  maxOI: "20000000000000" },
  { symbol:"SOLUSDT",  maxLev:50,  makerFee:2,  takerFee:5,  mmBps:100, maxOI: "15000000000000" },
  { symbol:"ADAUSDT",  maxLev:50,  makerFee:2,  takerFee:5,  mmBps:100, maxOI: "10000000000000" },
  { symbol:"XRPUSDT",  maxLev:75,  makerFee:2,  takerFee:5,  mmBps:75,  maxOI: "15000000000000" },
  { symbol:"DOGEUSDT", maxLev:50,  makerFee:2,  takerFee:5,  mmBps:100, maxOI: "5000000000000"  },
  { symbol:"DOTUSDT",  maxLev:50,  makerFee:2,  takerFee:5,  mmBps:100, maxOI: "5000000000000"  },
  { symbol:"AVAXUSDT", maxLev:50,  makerFee:2,  takerFee:5,  mmBps:100, maxOI: "5000000000000"  },
  { symbol:"LINKUSDT", maxLev:50,  makerFee:2,  takerFee:5,  mmBps:100, maxOI: "5000000000000"  },
  { symbol:"UNIUSDT",  maxLev:25,  makerFee:2,  takerFee:5,  mmBps:200, maxOI: "3000000000000"  },
  { symbol:"MATICUSDT",maxLev:50,  makerFee:2,  takerFee:5,  mmBps:100, maxOI: "5000000000000"  },
  { symbol:"GMXUSDT",  maxLev:25,  makerFee:2,  takerFee:5,  mmBps:200, maxOI: "2000000000000"  },
];

// Spot pools to create
const SPOT_POOLS = [
  { tokenA: "USDC", tokenB: "WETH", feeBps: 30 },
  { tokenA: "USDC", tokenB: "WBTC", feeBps: 30 },
  { tokenA: "USDC", tokenB: "ARB",  feeBps: 30 },
  { tokenA: "WETH", tokenB: "ARB",  feeBps: 30 },
];

// Arbitrum token addresses
const TOKENS = {
  USDC: "0xaf88d065e77c8cC2239327C5EDb3A432268e5831",
  WETH: "0x82aF49447D8a07e3bd95BD0d56f35241523fBab1",
  WBTC: "0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f",
  ARB:  "0x912CE59144191C1204E64559FE8253a0e49E6548",
};

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("\n🚀 Deploying Wikicious contracts to Arbitrum Mainnet");
  console.log(`   Deployer: ${deployer.address}`);
  console.log(`   Balance:  ${ethers.formatEther(await ethers.provider.getBalance(deployer.address))} ETH\n`);

  const deployments = {};

  // 1. WIK Token
  console.log("📦 Deploying WIKToken...");
  const WIKToken = await ethers.getContractFactory("WIKToken");
  const wik = await WIKToken.deploy(deployer.address);
  await wik.waitForDeployment();
  deployments.WIKToken = await wik.getAddress();
  console.log(`   ✅ WIKToken: ${deployments.WIKToken}`);

  // 2. Oracle
  console.log("📦 Deploying WikiOracle...");
  const WikiOracle = await ethers.getContractFactory("WikiOracle");
  const oracle = await WikiOracle.deploy(deployer.address);
  await oracle.waitForDeployment();
  deployments.WikiOracle = await oracle.getAddress();
  console.log(`   ✅ WikiOracle: ${deployments.WikiOracle}`);

  // 3. Vault
  console.log("📦 Deploying WikiVault...");
  const WikiVault = await ethers.getContractFactory("WikiVault");
  const vault = await WikiVault.deploy(TOKENS.USDC, deployer.address);
  await vault.waitForDeployment();
  deployments.WikiVault = await vault.getAddress();
  console.log(`   ✅ WikiVault: ${deployments.WikiVault}`);

  // 4. Perpetuals
  console.log("📦 Deploying WikiPerp...");
  const WikiPerp = await ethers.getContractFactory("WikiPerp");
  const perp = await WikiPerp.deploy(deployments.WikiVault, deployments.WikiOracle, deployer.address);
  await perp.waitForDeployment();
  deployments.WikiPerp = await perp.getAddress();
  console.log(`   ✅ WikiPerp: ${deployments.WikiPerp}`);

  // 5. GMX Backstop (replaces WikiAMM — no seed capital needed)
  console.log("📦 Deploying WikiGMXBackstop...");
  const WikiGMXBackstop = await ethers.getContractFactory("WikiGMXBackstop");
  const gmxBackstop = await WikiGMXBackstop.deploy(
    deployments.WikiVault, deployments.WikiOracle, deployer.address, deployer.address
  );
  await gmxBackstop.waitForDeployment();
  deployments.WikiGMXBackstop = await gmxBackstop.getAddress();
  console.log(`   ✅ WikiGMXBackstop: ${deployments.WikiGMXBackstop}`);
  console.log(`      → Uses GMX V2 liquidity — no seed capital required`);

  // 6. Spot Router (replaces WikiSpot — routes through Uniswap V3)
  console.log("📦 Deploying WikiSpotRouter...");
  const WikiSpotRouter = await ethers.getContractFactory("WikiSpotRouter");
  const spotRouter = await WikiSpotRouter.deploy(deployer.address, deployer.address);
  await spotRouter.waitForDeployment();
  deployments.WikiSpotRouter = await spotRouter.getAddress();
  console.log(`   ✅ WikiSpotRouter: ${deployments.WikiSpotRouter}`);
  console.log(`      → Routes through Uniswap V3, Wikicious earns 0.15% spread`);

  // ── Configure ─────────────────────────────────────────────
  console.log("\n⚙️  Configuring contracts...");

  // Vault operators: perp + gmx backstop
  await vault.setOperator(deployments.WikiPerp, true);
  await vault.setOperator(deployments.WikiGMXBackstop, true);
  console.log("   ✅ Vault operators set");

  // Wire GMX backstop into WikiPerp
  await perp.setGMXBackstop(deployments.WikiGMXBackstop, true);
  console.log("   ✅ GMX backstop wired into WikiPerp");

  // Authorize WikiPerp to call GMX backstop
  await gmxBackstop.setOperator(deployments.WikiPerp, true);
  console.log("   ✅ WikiPerp authorized as GMX backstop operator");

  // Fund WikiPerp with ETH for GMX execution fees (0.1 ETH = ~100 backstop orders)
  const ethForFees = ethers.parseEther("0.1");
  const fundTx = await deployer.sendTransaction({ to: deployments.WikiPerp, value: ethForFees });
  await fundTx.wait();
  console.log(`   ✅ Funded WikiPerp with 0.1 ETH for GMX execution fees`);

  // Set oracle feeds
  for (const [symbol, cfg] of Object.entries(CHAINLINK_FEEDS)) {
    const marketId = ethers.keccak256(ethers.toUtf8Bytes(symbol));
    await oracle.setFeed(marketId, cfg.feed, cfg.heartbeat, cfg.dec);
  }
  console.log(`   ✅ ${Object.keys(CHAINLINK_FEEDS).length} oracle feeds configured`);

  // Create perp markets
  for (const mkt of MARKETS) {
    const marketId = ethers.keccak256(ethers.toUtf8Bytes(mkt.symbol));
    await perp.createMarket(
      marketId, mkt.symbol, mkt.maxLev, mkt.makerFee, mkt.takerFee,
      mkt.mmBps, mkt.maxOI, mkt.maxOI
    );
  }
  console.log(`   ✅ ${MARKETS.length} perpetual markets created`);

  // Save deployments
  const outPath = path.join(__dirname, "../deployments.arbitrum.json");
  fs.writeFileSync(outPath, JSON.stringify({
    network: "arbitrum",
    chainId: 42161,
    deployer: deployer.address,
    timestamp: new Date().toISOString(),
    contracts: deployments,
    tokens: TOKENS,
    markets: MARKETS.map(m => m.symbol),
  }, null, 2));

  console.log(`\n✅ All contracts deployed and configured!`);
  console.log(`📄 Deployments saved to deployments.arbitrum.json`);
  console.log("\n📋 Summary:");
  for (const [name, addr] of Object.entries(deployments)) {
    console.log(`   ${name.padEnd(15)} ${addr}`);
  }
  console.log("\n⚠️  Next steps:");
  console.log("   1. Run: npx hardhat run scripts/verify.js --network arbitrum");
  console.log("   2. Add oracle guardian: oracle.setGuardian(YOUR_KEEPER_ADDRESS, true)");
  console.log("   3. Fund vault with initial USDC liquidity");
  console.log("   4. Start keeper bot: cd ../backend && npm run keeper");
}

main().catch(e => { console.error(e); process.exit(1); });
