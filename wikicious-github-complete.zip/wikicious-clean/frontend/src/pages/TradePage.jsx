import { useState, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { ConnectButton } from '@rainbow-me/rainbowkit';
import CandleChart from '../components/charts/CandleChart';
import OrderBook    from '../components/trading/OrderBook';
import TradeForm    from '../components/trading/TradeForm';
import PositionsTable from '../components/trading/PositionsTable';
import MarketSelector from '../components/markets/MarketSelector';
import { usePriceStore, useTradeStore, useUIStore } from '../store';
import { useWebSocket } from '../hooks/useApi';
import { MARKET_SYMBOLS } from '../config';
import clsx from 'clsx';

function PriceTicker({ symbol }) {
  const price   = usePriceStore(s => s.prices[symbol]) || 0;
  const change  = usePriceStore(s => s.changes?.[symbol]) || 0;
  const isUp    = change >= 0;

  const fmt = (p) => {
    if (p >= 10000) return p.toLocaleString('en', {minimumFractionDigits:2});
    if (p >= 100)   return p.toFixed(2);
    if (p >= 1)     return p.toFixed(4);
    return p.toFixed(6);
  };

  return (
    <div className="flex items-center gap-4 px-4">
      <div>
        <span className={clsx('text-2xl font-bold font-mono', isUp ? 'text-[#00D4A0]' : 'text-[#FF4F6B]')}>
          ${fmt(price)}
        </span>
        <span className={clsx('ml-2 text-sm font-mono', isUp ? 'text-[#00D4A0]' : 'text-[#FF4F6B]')}>
          {isUp ? '▲' : '▼'} {Math.abs(change).toFixed(2)}%
        </span>
      </div>
      <div className="h-8 w-px bg-[#222840]" />
      <div className="text-xs text-[#555C78] space-y-0.5">
        <div>24h High <span className="text-[#8A90A8] font-mono">${fmt(price * 1.032)}</span></div>
        <div>24h Low  <span className="text-[#8A90A8] font-mono">${fmt(price * 0.971)}</span></div>
      </div>
      <div className="text-xs text-[#555C78] space-y-0.5">
        <div>OI Long  <span className="text-[#00D4A0] font-mono">$2.4M</span></div>
        <div>OI Short <span className="text-[#FF4F6B] font-mono">$1.8M</span></div>
      </div>
      <div className="text-xs text-[#555C78] space-y-0.5">
        <div>Funding  <span className="text-[#5B7FFF] font-mono">+0.0100%</span></div>
        <div>Next     <span className="text-[#8A90A8] font-mono">02:14:33</span></div>
      </div>
    </div>
  );
}

const RIGHT_TABS = ['Book', 'Trades', 'Info'];
const BOTTOM_TABS = ['Positions', 'Orders', 'History'];

export default function TradePage() {
  const { symbol = 'BTCUSDT' } = useParams();
  const [rightTab, setRightTab]   = useState('Book');
  const [bottomTab, setBottomTab] = useState('Positions');
  const { chartInterval, setChartInterval } = useUIStore();
  const { setSymbol } = useTradeStore();
  const wsReady = useWebSocket();

  const handleSymbolSelect = useCallback((sym, idx) => {
    setSymbol(sym, idx);
    window.history.replaceState(null, '', `/trade/${sym}`);
  }, [setSymbol]);

  return (
    <div className="flex flex-col h-screen bg-[#08090D] text-white overflow-hidden">
      {/* Top bar */}
      <header className="flex items-center justify-between h-12 border-b border-[#222840] px-3 shrink-0">
        <div className="flex items-center gap-3">
          <a href="/" className="flex items-center gap-2 mr-2">
            <div className="w-6 h-6 bg-[#5B7FFF]/20 rounded flex items-center justify-center">
              <span className="text-[#5B7FFF] text-xs font-bold">W</span>
            </div>
            <span className="text-sm font-bold tracking-widest text-[#8A90A8]">WIKICIOUS</span>
          </a>
          {['Trade','Pool','Spot','Markets','Stats'].map(nav => (
            <a key={nav} href={`/${nav.toLowerCase()}`}
              className={clsx('text-xs font-medium transition-colors', nav === 'Trade' ? 'text-white' : 'text-[#555C78] hover:text-[#8A90A8]')}>
              {nav}
            </a>
          ))}
        </div>
        <div className="flex items-center gap-3">
          <div className={clsx('flex items-center gap-1.5 text-[10px] font-mono', wsReady ? 'text-[#00D4A0]' : 'text-[#555C78]')}>
            <span className={clsx('w-1.5 h-1.5 rounded-full', wsReady ? 'bg-[#00D4A0] animate-pulse' : 'bg-[#555C78]')} />
            {wsReady ? 'LIVE' : 'CONNECTING'}
          </div>
          <ConnectButton chainStatus="icon" showBalance={false} accountStatus="avatar" />
        </div>
      </header>

      {/* Market selector + ticker */}
      <div className="flex items-center h-11 border-b border-[#222840] shrink-0 gap-0">
        <MarketSelector currentSymbol={symbol} onSelect={handleSymbolSelect} />
        <div className="h-full w-px bg-[#222840]" />
        <div className="flex-1 flex items-center overflow-x-auto">
          <PriceTicker symbol={symbol} />
        </div>
      </div>

      {/* Main content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left: Chart + Positions */}
        <div className="flex flex-col flex-1 min-w-0 border-r border-[#222840]">
          {/* Chart */}
          <div className="flex-1 min-h-0">
            <CandleChart symbol={symbol} interval={chartInterval} onIntervalChange={setChartInterval} />
          </div>
          {/* Positions panel */}
          <div className="h-52 border-t border-[#222840] shrink-0">
            <PositionsTable />
          </div>
        </div>

        {/* Center-right: Book / Trades */}
        <div className="w-64 flex flex-col border-r border-[#222840] shrink-0">
          <div className="flex border-b border-[#222840]">
            {RIGHT_TABS.map(tab => (
              <button key={tab} onClick={() => setRightTab(tab)}
                className={clsx('flex-1 py-2 text-xs font-semibold transition-colors border-b-2',
                  rightTab === tab ? 'border-[#5B7FFF] text-white bg-[#5B7FFF]/5' : 'border-transparent text-[#555C78] hover:text-[#8A90A8]')}>
                {tab}
              </button>
            ))}
          </div>
          <div className="flex-1 overflow-hidden">
            {rightTab === 'Book' && <OrderBook symbol={symbol} />}
            {rightTab === 'Trades' && <RecentTradesFeed symbol={symbol} />}
            {rightTab === 'Info' && <MarketInfo symbol={symbol} />}
          </div>
        </div>

        {/* Right: Trade form */}
        <div className="w-72 shrink-0 flex flex-col">
          <div className="border-b border-[#222840] px-4 py-2 text-xs font-semibold text-[#555C78] uppercase tracking-wider">
            Place Order
          </div>
          <div className="flex-1 overflow-y-auto">
            <TradeForm />
          </div>
        </div>
      </div>
    </div>
  );
}

function RecentTradesFeed({ symbol }) {
  const { useRecentTrades } = require('../hooks/useApi');
  const { data: trades = [] } = useRecentTrades(symbol);
  const prices = usePriceStore(s => s.prices);

  // Generate synthetic trades if none
  const mock = Array.from({length:30}, (_,i) => {
    const p = (prices[symbol] || 100) * (1 + (Math.random()-0.5)*0.002);
    return { id:i, price:p, size:Math.random()*2, side:Math.random()>.5?'buy':'sell', ts:Date.now()-i*8000 };
  });
  const list = trades.length ? trades : mock;

  return (
    <div className="flex flex-col h-full">
      <div className="grid grid-cols-3 px-3 py-2 text-[10px] text-[#555C78] font-semibold uppercase border-b border-[#1a1e2e]">
        <span>Price</span><span className="text-right">Size</span><span className="text-right">Time</span>
      </div>
      <div className="flex-1 overflow-auto">
        {list.map((t, i) => (
          <div key={i} className="grid grid-cols-3 px-3 py-[3px] text-xs font-mono hover:bg-[#12151F]">
            <span className={t.side==='buy'?'text-[#00D4A0]':'text-[#FF4F6B]'}>{parseFloat(t.price).toFixed(2)}</span>
            <span className="text-right text-[#8A90A8]">{parseFloat(t.size).toFixed(4)}</span>
            <span className="text-right text-[#555C78]">{new Date(t.ts).toLocaleTimeString('en',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function MarketInfo({ symbol }) {
  return (
    <div className="p-4 text-xs space-y-3">
      <div>
        <div className="text-[#555C78] mb-2 font-semibold uppercase tracking-wide text-[10px]">Contract</div>
        <div className="space-y-1.5">
          {[['Type','Perpetual Futures'],['Margin','Cross / Isolated'],['Settlement','USDC'],['Chain','Arbitrum One']].map(([k,v]) => (
            <div key={k} className="flex justify-between">
              <span className="text-[#555C78]">{k}</span>
              <span className="text-[#8A90A8] font-mono">{v}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="h-px bg-[#222840]" />
      <div>
        <div className="text-[#555C78] mb-2 font-semibold uppercase tracking-wide text-[10px]">Fees</div>
        {[['Maker','0.02%'],['Taker','0.05%'],['Liquidation','0.50%']].map(([k,v]) => (
          <div key={k} className="flex justify-between mb-1.5">
            <span className="text-[#555C78]">{k}</span>
            <span className="text-[#8A90A8] font-mono">{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
