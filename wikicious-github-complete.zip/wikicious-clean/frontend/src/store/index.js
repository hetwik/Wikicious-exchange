import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import { WS_URL } from '../config';

// ── Price store ───────────────────────────────────────────────
export const usePriceStore = create(subscribeWithSelector((set, get) => ({
  prices:  {},   // symbol -> price
  changes: {},   // symbol -> 24h %
  volumes: {},   // symbol -> 24h vol
  ws:      null,
  wsReady: false,

  setPrice: (symbol, price) => set(s => ({ prices: { ...s.prices, [symbol]: price } })),
  setPrices: (updates) => set(s => ({ prices: { ...s.prices, ...updates } })),

  connectWs() {
    if (get().ws?.readyState === WebSocket.OPEN) return;
    const ws = new WebSocket(WS_URL);

    ws.onopen = () => {
      set({ wsReady: true });
      ws.send(JSON.stringify({ type: 'subscribe', channels: ['ticker','positions','liquidations','funding'] }));
    };

    ws.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data);
        if (msg.type === 'ticker') {
          set(s => ({ prices: { ...s.prices, ...msg.data } }));
        }
        // Dispatch to listeners
        get()._listeners?.forEach(fn => fn(msg));
      } catch {}
    };

    ws.onclose = () => {
      set({ wsReady: false, ws: null });
      setTimeout(() => get().connectWs(), 3000);
    };

    ws.onerror = () => ws.close();
    set({ ws });
  },

  _listeners: new Set(),
  subscribe(fn) {
    const s = get()._listeners; s.add(fn);
    return () => s.delete(fn);
  },

  getPrice: (symbol) => get().prices[symbol] ?? 0,
  getChange: (symbol) => get().changes[symbol] ?? 0,
})));

// ── Trading UI store ──────────────────────────────────────────
export const useTradeStore = create((set) => ({
  selectedSymbol: 'BTCUSDT',
  selectedMarketIndex: 0,
  side:      'long',   // 'long' | 'short'
  orderType: 'market', // 'market' | 'limit' | 'stop'
  leverage:  10,
  size:      '',
  price:     '',
  tpPrice:   '',
  slPrice:   '',
  reduceOnly: false,

  setSymbol: (symbol, idx) => set({ selectedSymbol: symbol, selectedMarketIndex: idx }),
  setSide:       (side)      => set({ side }),
  setOrderType:  (orderType) => set({ orderType }),
  setLeverage:   (leverage)  => set({ leverage }),
  setSize:       (size)      => set({ size }),
  setPrice:      (price)     => set({ price }),
  setTpPrice:    (tpPrice)   => set({ tpPrice }),
  setSlPrice:    (slPrice)   => set({ slPrice }),
  setReduceOnly: (r)         => set({ reduceOnly: r }),
  reset: () => set({ size:'', price:'', tpPrice:'', slPrice:'', reduceOnly:false }),
}));

// ── UI store ──────────────────────────────────────────────────
export const useUIStore = create((set) => ({
  sidebarOpen:  true,
  theme:        'dark',
  chartInterval: '1h',
  activeTab:    'chart', // 'chart' | 'orderbook' | 'trades'

  setSidebarOpen:   (v) => set({ sidebarOpen: v }),
  setChartInterval: (v) => set({ chartInterval: v }),
  setActiveTab:     (v) => set({ activeTab: v }),
}));
