import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';
import { API_URL } from '../config';
import { useEffect, useRef } from 'react';
import { usePriceStore } from '../store';

const api = axios.create({ baseURL: API_URL });

// Attach JWT
api.interceptors.request.use(cfg => {
  const token = localStorage.getItem('wik_token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

// ── Auth ──────────────────────────────────────────────────────
export function useLogin() {
  return useMutation({
    mutationFn: ({ email, password }) => api.post('/api/auth/login', { email, password }).then(r => r.data),
    onSuccess: (data) => { localStorage.setItem('wik_token', data.token); },
  });
}
export function useRegister() {
  return useMutation({
    mutationFn: (body) => api.post('/api/auth/register', body).then(r => r.data),
    onSuccess: (data) => { localStorage.setItem('wik_token', data.token); },
  });
}
export function useMe() {
  return useQuery({ queryKey: ['me'], queryFn: () => api.get('/api/auth/me').then(r => r.data), retry: false });
}

// ── Markets ───────────────────────────────────────────────────
export function useMarkets() {
  return useQuery({
    queryKey: ['markets'],
    queryFn: () => api.get('/api/markets').then(r => r.data),
    refetchInterval: 5000,
    staleTime: 1000,
  });
}

export function useCandles(symbol, interval, limit = 200) {
  return useQuery({
    queryKey: ['candles', symbol, interval],
    queryFn: () => api.get(`/api/markets/${symbol}/candles`, { params: { interval, limit } }).then(r => r.data),
    refetchInterval: interval === '1m' ? 10000 : 30000,
    staleTime: 5000,
  });
}

export function useOrderBook(symbol, depth = 25) {
  return useQuery({
    queryKey: ['orderbook', symbol],
    queryFn: () => api.get(`/api/markets/${symbol}/orderbook`, { params: { depth } }).then(r => r.data),
    refetchInterval: 1500,
    staleTime: 500,
  });
}

export function useRecentTrades(symbol) {
  return useQuery({
    queryKey: ['trades', symbol],
    queryFn: () => api.get(`/api/markets/${symbol}/trades`).then(r => r.data),
    refetchInterval: 3000,
  });
}

export function useFundingRate(symbol) {
  return useQuery({
    queryKey: ['funding', symbol],
    queryFn: () => api.get(`/api/markets/${symbol}/funding`).then(r => r.data),
    refetchInterval: 10000,
  });
}

// ── Account ───────────────────────────────────────────────────
export function useAccountBalance(address) {
  return useQuery({
    queryKey: ['balance', address],
    queryFn: () => api.get(`/api/account/${address}/balance`).then(r => r.data),
    enabled: !!address,
    refetchInterval: 5000,
  });
}

export function usePositions(address) {
  return useQuery({
    queryKey: ['positions', address],
    queryFn: () => api.get(`/api/account/${address}/positions`).then(r => r.data),
    enabled: !!address,
    refetchInterval: 3000,
  });
}

export function useOrders(address) {
  return useQuery({
    queryKey: ['orders', address],
    queryFn: () => api.get(`/api/account/${address}/orders`).then(r => r.data),
    enabled: !!address,
    refetchInterval: 3000,
  });
}

// ── Pool ──────────────────────────────────────────────────────
export function usePoolStats() {
  return useQuery({
    queryKey: ['pool'],
    queryFn: () => api.get('/api/pool/stats').then(r => r.data),
    refetchInterval: 10000,
  });
}

// ── Leaderboard ───────────────────────────────────────────────
export function useLeaderboard() {
  return useQuery({
    queryKey: ['leaderboard'],
    queryFn: () => api.get('/api/leaderboard').then(r => r.data),
    refetchInterval: 30000,
  });
}

// ── WebSocket price hook ──────────────────────────────────────
export function useWebSocket() {
  const connectWs = usePriceStore(s => s.connectWs);
  const wsReady = usePriceStore(s => s.wsReady);
  useEffect(() => { connectWs(); }, [connectWs]);
  return wsReady;
}

export function useWsMessages(handler) {
  const subscribe = usePriceStore(s => s.subscribe);
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => subscribe((msg) => ref.current(msg)), [subscribe]);
}

export { api };
