import { useReadContract, useWriteContract, useWaitForTransactionReceipt, useAccount } from 'wagmi';
import { parseUnits, formatUnits, erc20Abi } from 'viem';
import { useState, useCallback } from 'react';
import { CONTRACTS } from '../config';

// ABIs (minimal — full in backend/src/config.js)
const VAULT_ABI = [
  { name:'deposit',       type:'function', inputs:[{type:'uint256'}], outputs:[] },
  { name:'withdraw',      type:'function', inputs:[{type:'uint256'}], outputs:[] },
  { name:'freeMargin',    type:'function', stateMutability:'view', inputs:[{type:'address'}], outputs:[{type:'uint256'}] },
  { name:'lockedMargin',  type:'function', stateMutability:'view', inputs:[{type:'address'}], outputs:[{type:'uint256'}] },
];

const PERP_ABI = [
  { name:'placeMarketOrder', type:'function', inputs:[{type:'uint256'},{type:'bool'},{type:'uint256'},{type:'uint256'},{type:'uint256'},{type:'uint256'}], outputs:[{type:'uint256'}] },
  { name:'placeLimitOrder',  type:'function', inputs:[{type:'uint256'},{type:'bool'},{type:'uint256'},{type:'uint256'},{type:'uint256'},{type:'uint256'},{type:'uint256'}], outputs:[{type:'uint256'}] },
  { name:'closePosition',    type:'function', inputs:[{type:'uint256'}], outputs:[] },
  { name:'cancelOrder',      type:'function', inputs:[{type:'uint256'}], outputs:[] },
  { name:'getMarket',        type:'function', stateMutability:'view', inputs:[{type:'uint256'}], outputs:[{type:'tuple',components:[{name:'marketId',type:'bytes32'},{name:'symbol',type:'string'},{name:'maxLeverage',type:'uint256'},{name:'makerFeeBps',type:'uint256'},{name:'takerFeeBps',type:'uint256'},{name:'maintenanceMarginBps',type:'uint256'},{name:'maxOpenInterestLong',type:'uint256'},{name:'maxOpenInterestShort',type:'uint256'},{name:'openInterestLong',type:'uint256'},{name:'openInterestShort',type:'uint256'},{name:'fundingRate',type:'int256'},{name:'lastFundingTime',type:'uint256'},{name:'cumulativeFundingLong',type:'uint256'},{name:'cumulativeFundingShort',type:'uint256'},{name:'active',type:'bool'}]}] },
];

const AMM_ABI = [
  { name:'addLiquidity',    type:'function', inputs:[{type:'uint256'}], outputs:[{type:'uint256'}] },
  { name:'removeLiquidity', type:'function', inputs:[{type:'uint256'}], outputs:[{type:'uint256'}] },
  { name:'getWLPPrice',     type:'function', stateMutability:'view', inputs:[], outputs:[{type:'uint256'}] },
  { name:'totalSupply',     type:'function', stateMutability:'view', inputs:[], outputs:[{type:'uint256'}] },
];

// ── USDC Approval ─────────────────────────────────────────────
export function useUSDCAllowance(spender) {
  const { address } = useAccount();
  return useReadContract({
    address: CONTRACTS.USDC,
    abi: erc20Abi,
    functionName: 'allowance',
    args: [address, spender],
    query: { enabled: !!address && !!spender },
  });
}

export function useApproveUSDC() {
  const { writeContract, data, isPending } = useWriteContract();
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash: data });

  const approve = useCallback((spender, amount) => {
    writeContract({
      address: CONTRACTS.USDC,
      abi: erc20Abi,
      functionName: 'approve',
      args: [spender, amount],
    });
  }, [writeContract]);

  return { approve, isPending: isPending || isConfirming, isSuccess };
}

// ── Vault ─────────────────────────────────────────────────────
export function useVaultBalance(address) {
  const free = useReadContract({
    address: CONTRACTS.WikiVault,
    abi: VAULT_ABI,
    functionName: 'freeMargin',
    args: [address],
    query: { enabled: !!address },
  });
  const locked = useReadContract({
    address: CONTRACTS.WikiVault,
    abi: VAULT_ABI,
    functionName: 'lockedMargin',
    args: [address],
    query: { enabled: !!address },
  });
  return {
    freeMargin:   free.data   ? formatUnits(free.data, 6)   : '0',
    lockedMargin: locked.data ? formatUnits(locked.data, 6) : '0',
    isLoading: free.isLoading || locked.isLoading,
  };
}

export function useDeposit() {
  const { writeContract, data, isPending, error } = useWriteContract();
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash: data });

  const deposit = useCallback((usdcAmount) => {
    const parsed = parseUnits(String(usdcAmount), 6);
    writeContract({ address: CONTRACTS.WikiVault, abi: VAULT_ABI, functionName: 'deposit', args: [parsed] });
  }, [writeContract]);

  return { deposit, isPending: isPending || isConfirming, isSuccess, error, txHash: data };
}

export function useWithdraw() {
  const { writeContract, data, isPending, error } = useWriteContract();
  const { isLoading: isConfirming, isSuccess } = useWaitForTransactionReceipt({ hash: data });

  const withdraw = useCallback((usdcAmount) => {
    const parsed = parseUnits(String(usdcAmount), 6);
    writeContract({ address: CONTRACTS.WikiVault, abi: VAULT_ABI, functionName: 'withdraw', args: [parsed] });
  }, [writeContract]);

  return { withdraw, isPending: isPending || isConfirming, isSuccess, error, txHash: data };
}

// ── Perpetuals ────────────────────────────────────────────────
export function usePlaceOrder() {
  const { writeContract, data, isPending, error } = useWriteContract();
  const { isLoading: isConfirming, isSuccess, data: receipt } = useWaitForTransactionReceipt({ hash: data });
  const [lastTx, setLastTx] = useState(null);

  const placeMarketOrder = useCallback(({ marketIndex, isLong, collateral, leverage, takeProfit = 0, stopLoss = 0 }) => {
    const col  = parseUnits(String(collateral), 6);
    const tp   = takeProfit  ? parseUnits(String(takeProfit), 18)  : 0n;
    const sl   = stopLoss    ? parseUnits(String(stopLoss), 18)    : 0n;
    writeContract({ address: CONTRACTS.WikiPerp, abi: PERP_ABI, functionName: 'placeMarketOrder', args: [BigInt(marketIndex), isLong, col, BigInt(leverage), tp, sl] });
    setLastTx({ marketIndex, isLong, collateral, leverage });
  }, [writeContract]);

  const placeLimitOrder = useCallback(({ marketIndex, isLong, collateral, leverage, limitPrice, takeProfit = 0, stopLoss = 0 }) => {
    const col  = parseUnits(String(collateral), 6);
    const lp   = parseUnits(String(limitPrice), 18);
    const tp   = takeProfit  ? parseUnits(String(takeProfit), 18)  : 0n;
    const sl   = stopLoss    ? parseUnits(String(stopLoss), 18)    : 0n;
    writeContract({ address: CONTRACTS.WikiPerp, abi: PERP_ABI, functionName: 'placeLimitOrder', args: [BigInt(marketIndex), isLong, col, BigInt(leverage), lp, tp, sl] });
  }, [writeContract]);

  return { placeMarketOrder, placeLimitOrder, isPending: isPending || isConfirming, isSuccess, error, txHash: data };
}

export function useClosePosition() {
  const { writeContract, data, isPending } = useWriteContract();
  const { isSuccess } = useWaitForTransactionReceipt({ hash: data });
  const close = useCallback((posId) => {
    writeContract({ address: CONTRACTS.WikiPerp, abi: PERP_ABI, functionName: 'closePosition', args: [BigInt(posId)] });
  }, [writeContract]);
  return { close, isPending, isSuccess };
}

export function useCancelOrder() {
  const { writeContract, data, isPending } = useWriteContract();
  const { isSuccess } = useWaitForTransactionReceipt({ hash: data });
  const cancel = useCallback((orderId) => {
    writeContract({ address: CONTRACTS.WikiPerp, abi: PERP_ABI, functionName: 'cancelOrder', args: [BigInt(orderId)] });
  }, [writeContract]);
  return { cancel, isPending, isSuccess };
}

// ── AMM Pool ──────────────────────────────────────────────────
export function useWLPPrice() {
  return useReadContract({ address: CONTRACTS.WikiAMM, abi: AMM_ABI, functionName: 'getWLPPrice' });
}

export function useAddLiquidity() {
  const { writeContract, data, isPending } = useWriteContract();
  const { isSuccess } = useWaitForTransactionReceipt({ hash: data });
  const add = useCallback((usdcAmount) => {
    writeContract({ address: CONTRACTS.WikiAMM, abi: AMM_ABI, functionName: 'addLiquidity', args: [parseUnits(String(usdcAmount), 6)] });
  }, [writeContract]);
  return { add, isPending, isSuccess };
}
