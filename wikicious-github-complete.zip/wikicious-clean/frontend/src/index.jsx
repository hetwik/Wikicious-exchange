import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { WagmiProvider } from 'wagmi';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { RainbowKitProvider, darkTheme } from '@rainbow-me/rainbowkit';
import '@rainbow-me/rainbowkit/styles.css';
import { wagmiConfig } from './config';
import TradePage from './pages/TradePage';
import MarketsPage from './pages/MarketsPage';
import PoolPage from './pages/PoolPage';
import './index.css';

const queryClient = new QueryClient({
  defaultOptions: { queries: { refetchOnWindowFocus: false, retry: 1 } }
});

const RK_THEME = darkTheme({
  accentColor:          '#5B7FFF',
  accentColorForeground:'#fff',
  borderRadius:         'medium',
  overlayBlur:          'small',
});
RK_THEME.colors.modalBackground     = '#0D0F17';
RK_THEME.colors.modalBorder         = '#222840';
RK_THEME.colors.menuItemBackground  = '#12151F';
RK_THEME.colors.profileForeground   = '#12151F';

export default function App() {
  return (
    <WagmiProvider config={wagmiConfig}>
      <QueryClientProvider client={queryClient}>
        <RainbowKitProvider theme={RK_THEME} modalSize="compact">
          <BrowserRouter>
            <Routes>
              <Route path="/"               element={<Navigate to="/trade/BTCUSDT" replace />} />
              <Route path="/trade/:symbol"  element={<TradePage />} />
              <Route path="/trade"          element={<Navigate to="/trade/BTCUSDT" replace />} />
              <Route path="/markets"        element={<MarketsPage />} />
              <Route path="/pool"           element={<PoolPage />} />
            </Routes>
          </BrowserRouter>
        </RainbowKitProvider>
      </QueryClientProvider>
    </WagmiProvider>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
