// Wikicious Frontend — wagmi + RainbowKit + Arbitrum config
import { getDefaultConfig } from '@rainbow-me/rainbowkit';
import { arbitrum } from 'wagmi/chains';
import { http } from 'wagmi';

export const API_URL = process.env.REACT_APP_API_URL || 'https://api.wikicious.io';
export const WS_URL  = process.env.REACT_APP_WS_URL  || 'wss://api.wikicious.io/ws';

// Contract addresses (set after deploy)
export const CONTRACTS = {
  WikiVault:  process.env.REACT_APP_VAULT_ADDRESS  || '',
  WikiPerp:   process.env.REACT_APP_PERP_ADDRESS   || '',
  WikiAMM:    process.env.REACT_APP_AMM_ADDRESS    || '',
  WikiSpot:   process.env.REACT_APP_SPOT_ADDRESS   || '',
  WIKToken:   process.env.REACT_APP_WIK_ADDRESS    || '',
  USDC:       '0xaf88d065e77c8cC2239327C5EDb3A432268e5831',
};

export const wagmiConfig = getDefaultConfig({
  appName:     'Wikicious Exchange',
  projectId:   process.env.REACT_APP_WALLETCONNECT_ID || 'wikicious',
  chains:      [arbitrum],
  transports:  { [arbitrum.id]: http() },
});

// Market index → symbol map (matches contract deploy order)
export const MARKET_SYMBOLS = [
  'BTCUSDT','ETHUSDT','ARBUSDT','OPUSDT','BNBUSDT','SOLUSDT',
  'ADAUSDT','XRPUSDT','DOGEUSDT','DOTUSDT','AVAXUSDT','LINKUSDT',
  'UNIUSDT','MATICUSDT','GMXUSDT',
];
