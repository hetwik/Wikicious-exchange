# Wikicious Exchange

Decentralised perpetuals exchange on Arbitrum. Trade crypto, forex (100+ pairs), gold, silver, oil and more — all synthetic, settled in USDC.

## Structure

```
wikicious/
├── contracts/     Solidity smart contracts (Hardhat)
├── backend/       Node.js API + keeper services
├── frontend/      React trading UI (Vite + wagmi)
├── mobile/        Flutter app (iOS + Android)
├── nginx/         Reverse proxy config
└── scripts/       VPS setup scripts
```

## Markets
- Crypto — BTC, ETH, SOL, ARB + 8 more (125x)
- Forex Major — EUR/USD, GBP/USD, JPY + 4 more (50x)
- Forex Minor — EUR/GBP, EUR/JPY + 13 derived pairs (30x)
- Forex Exotic — TRY, ZAR, NGN, KRW, THB + 16 more (20x)
- Metals — Gold (100x), Silver, Platinum, Palladium
- Commodities — WTI Oil, Brent, Natural Gas

## Quick Start

```bash
# Contracts
cd contracts && cp .env.example .env && npm install
npx hardhat run scripts/deploy.js --network arbitrum

# Backend
cd backend && cp .env.example .env && npm install && npm start

# Frontend
cd frontend && cp .env.example .env && npm install && npm run dev

# Mobile
cd mobile && flutter pub get && flutter run
```

## Deploy
See the deployment guide (wikicious_deployment_guide.docx) for full instructions.
