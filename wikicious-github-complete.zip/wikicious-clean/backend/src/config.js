'use strict';
// Auto-generated from deployments.arbitrum.json
// Run: node scripts/gen-config.js after deployment

const ADDRESSES = {
  WikiGMXBackstop: process.env.GMX_BACKSTOP_ADDRESS || '',
  WikiSpotRouter:  process.env.SPOT_ROUTER_ADDRESS  || '',
  WikiVault:  process.env.VAULT_ADDRESS  || "",
  WikiPerp:   process.env.PERP_ADDRESS   || "",
  WikiAMM:    process.env.AMM_ADDRESS    || "",
  WikiSpot:   process.env.SPOT_ADDRESS   || "",
  WikiOracle: process.env.ORACLE_ADDRESS || "",
  WIKToken:   process.env.WIK_ADDRESS    || "",
  USDC:       "0xaf88d065e77c8cC2239327C5EDb3A432268e5831",
};

const VAULT_ABI = [
  "function deposit(uint256 amount) external",
  "function withdraw(uint256 amount) external",
  "function freeMargin(address user) view returns (uint256)",
  "function lockedMargin(address user) view returns (uint256)",
  "function totalMargin(address user) view returns (uint256)",
  "function accounts(address) view returns (uint256 balance, uint256 locked, uint256 totalDeposited, uint256 totalWithdrawn)",
  "event Deposit(address indexed user, uint256 amount)",
  "event Withdrawal(address indexed user, uint256 amount)",
  "event PnLSettled(address indexed user, int256 pnl)",
];

const PERP_ABI = [
  "function placeMarketOrder(uint256 marketIndex, bool isLong, uint256 collateral, uint256 leverage, uint256 takeProfit, uint256 stopLoss) external returns (uint256)",
  "function placeLimitOrder(uint256 marketIndex, bool isLong, uint256 collateral, uint256 leverage, uint256 limitPrice, uint256 takeProfit, uint256 stopLoss) external returns (uint256)",
  "function cancelOrder(uint256 orderId) external",
  "function closePosition(uint256 posId) external",
  "function liquidate(uint256 posId) external",
  "function executeTPSL(uint256 posId) external",
  "function settleFunding(uint256 marketIndex) external",
  "function executeLimitOrders(uint256 marketIndex, uint256[] calldata orderIds) external",
  "function getPosition(uint256 posId) view returns (tuple(address trader, uint256 marketIndex, bool isLong, uint256 size, uint256 collateral, uint256 entryPrice, uint256 entryFunding, uint256 leverage, uint256 liquidationPrice, uint256 takeProfit, uint256 stopLoss, uint256 openedAt, bool open))",
  "function getOrder(uint256 orderId) view returns (tuple(address trader, uint256 marketIndex, bool isLong, bool isLimit, uint256 size, uint256 collateral, uint256 limitPrice, uint256 leverage, uint256 takeProfit, uint256 stopLoss, bool reduceOnly, uint256 createdAt, bool open))",
  "function getMarket(uint256 idx) view returns (tuple(bytes32 marketId, string symbol, uint256 maxLeverage, uint256 makerFeeBps, uint256 takerFeeBps, uint256 maintenanceMarginBps, uint256 maxOpenInterestLong, uint256 maxOpenInterestShort, uint256 openInterestLong, uint256 openInterestShort, int256 fundingRate, uint256 lastFundingTime, uint256 cumulativeFundingLong, uint256 cumulativeFundingShort, bool active))",
  "function marketCount() view returns (uint256)",
  "function getTraderPositions(address trader) view returns (uint256[])",
  "function getTraderOrders(address trader) view returns (uint256[])",
  "function getUnrealizedPnL(uint256 posId) view returns (int256)",
  "event OrderPlaced(uint256 indexed orderId, address indexed trader, uint256 marketIndex, bool isLong, uint256 size)",
  "event OrderFilled(uint256 indexed orderId, uint256 indexed positionId, uint256 fillPrice)",
  "event PositionOpened(uint256 indexed positionId, address indexed trader, bool isLong, uint256 size, uint256 price)",
  "event PositionClosed(uint256 indexed positionId, address indexed trader, int256 pnl, uint256 closePrice)",
  "event PositionLiquidated(uint256 indexed positionId, address indexed trader, address liquidator, uint256 price)",
  "event FundingSettled(uint256 indexed marketIndex, int256 rate, uint256 timestamp)",
];

const AMM_ABI = [
  "function addLiquidity(uint256 usdcAmount) external returns (uint256 wlpOut)",
  "function removeLiquidity(uint256 wlpAmount) external returns (uint256 usdcOut)",
  "function getAUM() view returns (uint256)",
  "function getWLPPrice() view returns (uint256)",
  "function getPoolStats() view returns (tuple(uint256 totalLiquidity, uint256 reservedForLongs, uint256 reservedForShorts, uint256 totalFeesEarned, uint256 totalPnlPaid, uint256 lastAUM))",
  "function balanceOf(address) view returns (uint256)",
  "function totalSupply() view returns (uint256)",
  "event LiquidityAdded(address indexed lp, uint256 usdcAmount, uint256 wlpMinted)",
  "event LiquidityRemoved(address indexed lp, uint256 wlpBurned, uint256 usdcAmount)",
];

const SPOT_ABI = [
  "function swapExactIn(uint256 poolId, address tokenIn, uint256 amtIn, uint256 minOut, address recipient) external returns (uint256)",
  "function addLiquidity(uint256 poolId, uint256 amtA, uint256 amtB, uint256 minLP) external returns (uint256)",
  "function removeLiquidity(uint256 poolId, uint256 lpAmount, uint256 minA, uint256 minB) external returns (uint256, uint256)",
  "function getAmountOut(uint256 poolId, address tokenIn, uint256 amtIn) view returns (uint256 amtOut, uint256 priceImpactBps)",
  "function getPool(uint256 poolId) view returns (tuple(address tokenA, address tokenB, uint256 reserveA, uint256 reserveB, uint256 totalLP, uint256 feeBps, uint256 volumeA, uint256 volumeB, bool active))",
  "function poolCount() view returns (uint256)",
  "event Swap(uint256 indexed poolId, address indexed trader, address tokenIn, uint256 amtIn, address tokenOut, uint256 amtOut)",
];

const ORACLE_ABI = [
  "function getPrice(bytes32 marketId) view returns (uint256 price, uint256 timestamp)",
  "function getPriceSafe(bytes32 marketId) view returns (uint256 price, bool valid)",
  "function submitGuardianPrice(bytes32 marketId, uint256 price) external",
];

const ERC20_ABI = [
  "function approve(address spender, uint256 amount) external returns (bool)",
  "function allowance(address owner, address spender) view returns (uint256)",
  "function balanceOf(address account) view returns (uint256)",
  "function decimals() view returns (uint8)",
];

module.exports = { ADDRESSES, VAULT_ABI, PERP_ABI, AMM_ABI, SPOT_ABI, ORACLE_ABI, ERC20_ABI };
