'use strict';
const WebSocket = require('ws');
const EventEmitter = require('events');

// All Binance USDT pairs (300+)
const PAIRS = [
  'BTCUSDT','ETHUSDT','BNBUSDT','SOLUSDT','ADAUSDT','XRPUSDT','DOGEUSDT',
  'MATICUSDT','AVAXUSDT','LINKUSDT','UNIUSDT','ATOMUSDT','DOTUSDT','LTCUSDT',
  'ETCUSDT','XLMUSDT','ALGOUSDT','NEARUSDT','APTUSDT','ARBUSDT','OPUSDT',
  'INJUSDT','SUIUSDT','SEIUSDT','TIAUSDT','WLDUSDT','RENDERUSDT','FTMUSDT',
  'AAVEUSDT','MKRUSDT','COMPUSDT','CRVUSDT','LDOUSDT','STXUSDT','RUNEUSDT',
  'GRTUSDT','FETUSDT','AGIXUSDT','SANDUSDT','MANAUSDT','AXSUSDT','GALAUSDT',
  'ENSUSDT','QNTUSDT','FLOWUSDT','HBARUSDT','EGLDUSDT','XTZUSDT','IOTAUSDT',
  'ZECUSDT','XMRUSDT','DASHUSDT','NEOUSDT','GMTUSDT','APEUSDT','DYDXUSDT',
  'BLURUSDT','WOOUSDT','MASKUSDT','ANKRUSDT','SNXUSDT','YFIUSDT','BALUSDT',
  'SUSHIUSDT','CVXUSDT','JUPUSDT','JTOUSDT','PYTHUSDT','DYMUSDT','GMXUSDT',
  'BONKUSDT','WIFUSDT','PEPEUSDT','FLOKIUSDT','SHIBUSDT','ORDIUSDT','BOMEUSDT',
  '1000PEPEUSDT','1000SHIBUSDT','LRCUSDT','STORJUSDT','OCEANUSDT','BATUSDT',
  'ZRXUSDT','ICXUSDT','IOSTUSDT','ENJUSDT','CAKEUSDT','RUNEUSDT','VETUSDT',
  'THETAUSDT','FILUSDT','TRXUSDT','EOSUSDT','RNDRUSDT','PERPUSDT','HIGHUSDT',
  'MINAUSDT','STGUSDT','HOOKUSDT','MAGICUSDT','AMBUSDT','CFXUSDT','IDUSDT',
  'WUSDT','ENAUSDT','ALTUSDT','PIXELUSDT','ACEUSDT','XAIUSDT','ZETAUSDT',
  'MANTAUSDT','RONINUSDT','SAGAUSDT','TNSR','REZUSDT','BBUSDT','NOTUSDT',
  'IOUSDT','ZKUSDT','LISTAUSDT','ZROUSDT','BRETTUSDT','DOGSWIFHATUSDT',
];

class PriceService extends EventEmitter {
  constructor() {
    super();
    this.prices = {};        // symbol -> price
    this.changes = {};       // symbol -> 24h change pct
    this.volumes = {};       // symbol -> 24h volume
    this._ws = null;
    this._reconnectTimer = null;
    this._simInterval = null;
    this._connected = false;
  }

  start() {
    this._connect();
    console.log('📡 Price service started');
  }

  _connect() {
    const ws = new WebSocket('wss://stream.binance.com:9443/ws/!miniTicker@arr', { handshakeTimeout: 10000 });
    this._ws = ws;

    ws.on('open', () => {
      this._connected = true;
      if (this._simInterval) { clearInterval(this._simInterval); this._simInterval = null; }
      console.log('✅ Connected to Binance WebSocket');
    });

    ws.on('message', (raw) => {
      try {
        const tickers = JSON.parse(raw);
        if (!Array.isArray(tickers)) return;
        const updates = {};
        for (const t of tickers) {
          const price = parseFloat(t.c);
          if (price > 0) {
            const prev = this.prices[t.s];
            this.prices[t.s]  = price;
            this.changes[t.s] = parseFloat(t.P); // 24h change %
            this.volumes[t.s] = parseFloat(t.q); // quote volume
            if (prev !== price) updates[t.s] = price;
          }
        }
        if (Object.keys(updates).length) this.emit('update', updates);
      } catch {}
    });

    ws.on('close', () => {
      this._connected = false;
      this._startSim();
      this._reconnectTimer = setTimeout(() => this._connect(), 5000);
    });

    ws.on('error', () => ws.close());
  }

  _startSim() {
    if (this._simInterval) return;
    const seeds = {
      BTCUSDT:67420, ETHUSDT:3842, BNBUSDT:580, SOLUSDT:184, ARBUSDT:1.84,
      OPUSDT:3.21, DOGEUSDT:0.18, ADAUSDT:0.62, XRPUSDT:0.72, NEARUSDT:7.8,
      AVAXUSDT:42, LINKUSDT:18, MATICUSDT:0.91, LDOUSDT:2.8, GMXUSDT:28,
    };
    for (const [k, v] of Object.entries(seeds)) if (!this.prices[k]) { this.prices[k] = v; this.changes[k] = 0; }
    this._simInterval = setInterval(() => {
      const updates = {};
      for (const [sym, p] of Object.entries(this.prices)) {
        const change = (Math.random() - 0.499) * p * 0.001;
        this.prices[sym] = Math.max(0.000001, p + change);
        updates[sym] = this.prices[sym];
      }
      this.emit('update', updates);
    }, 300);
  }

  getPrice(symbol) { return this.prices[symbol] || null; }
  getChange(symbol) { return this.changes[symbol] || 0; }
  getVolume(symbol) { return this.volumes[symbol] || 0; }
  getAllPrices() { return { ...this.prices }; }

  getMarketData(symbol) {
    return {
      symbol, price: this.prices[symbol] || 0,
      change24h: this.changes[symbol] || 0,
      volume24h: this.volumes[symbol] || 0,
    };
  }

  stop() {
    if (this._ws) this._ws.close();
    if (this._simInterval) clearInterval(this._simInterval);
    if (this._reconnectTimer) clearTimeout(this._reconnectTimer);
  }
}

module.exports = new PriceService();
