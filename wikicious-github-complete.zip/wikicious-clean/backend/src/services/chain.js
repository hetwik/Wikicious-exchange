'use strict';
const { ethers } = require('ethers');
const { ADDRESSES, VAULT_ABI, PERP_ABI, AMM_ABI, SPOT_ABI, ORACLE_ABI, ERC20_ABI } = require('../config');

const RPC_URL     = process.env.ARBITRUM_RPC_URL || 'https://arb1.arbitrum.io/rpc';
const WS_RPC_URL  = process.env.ARBITRUM_WS_URL  || 'wss://arb1.arbitrum.io/ws';
const KEEPER_KEY  = process.env.KEEPER_PRIVATE_KEY;

let _provider, _wsProvider, _keeper;
let _vault, _perp, _amm, _spot, _oracle, _usdc;

function getProvider() {
  if (!_provider) {
    _provider = new ethers.JsonRpcProvider(RPC_URL);
  }
  return _provider;
}

function getWsProvider() {
  if (!_wsProvider) {
    try {
      _wsProvider = new ethers.WebSocketProvider(WS_RPC_URL);
      _wsProvider.on('error', () => { _wsProvider = null; });
    } catch {
      _wsProvider = getProvider();
    }
  }
  return _wsProvider;
}

function getKeeper() {
  if (!KEEPER_KEY) return null;
  if (!_keeper) _keeper = new ethers.Wallet(KEEPER_KEY, getProvider());
  return _keeper;
}

function getVault()  { if (!_vault)  _vault  = new ethers.Contract(ADDRESSES.WikiVault,  VAULT_ABI,  getProvider()); return _vault; }
function getPerp()   { if (!_perp)   _perp   = new ethers.Contract(ADDRESSES.WikiPerp,   PERP_ABI,   getProvider()); return _perp; }
function getAMM()    { if (!_amm)    _amm    = new ethers.Contract(ADDRESSES.WikiAMM,    AMM_ABI,    getProvider()); return _amm; }
function getSpot()   { if (!_spot)   _spot   = new ethers.Contract(ADDRESSES.WikiSpot,   SPOT_ABI,   getProvider()); return _spot; }
function getOracle() { if (!_oracle) _oracle = new ethers.Contract(ADDRESSES.WikiOracle, ORACLE_ABI, getProvider()); return _oracle; }
function getUSDC()   { if (!_usdc)   _usdc   = new ethers.Contract(ADDRESSES.USDC,       ERC20_ABI,  getProvider()); return _usdc; }

function getKeeperContract(abi, address) {
  const keeper = getKeeper();
  if (!keeper) throw new Error('No keeper key configured');
  return new ethers.Contract(address, abi, keeper);
}

async function getBlockNumber() { return getProvider().getBlockNumber(); }
async function getGasPrice() {
  const fee = await getProvider().getFeeData();
  return fee.gasPrice || ethers.parseUnits('0.1', 'gwei');
}

module.exports = {
  getProvider, getWsProvider, getKeeper, getKeeperContract,
  getVault, getPerp, getAMM, getSpot, getOracle, getUSDC,
  getBlockNumber, getGasPrice,
  ADDRESSES, PERP_ABI, VAULT_ABI, AMM_ABI, SPOT_ABI, ORACLE_ABI, ERC20_ABI,
};
